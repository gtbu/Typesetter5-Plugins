<?php
// Setting Language is easy, simply uncomment the desired Language
// or insert the desired countrycode
// English and German is managed by me, the Author.
// German is my native Language, so always reference to it if in doubt

//German
//require ('languages/de.php');

//USA
require ('languages/us.php');

//English
//require ('languages/en.php');
