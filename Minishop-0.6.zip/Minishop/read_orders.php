<?php
defined('is_running') or die('Not an entry point...');

echo ' <hr size=1> ';

echo ' <div class="ck_inst" style="padding:20px;font-size:15px; background-color: transparent;border: 1px solid silver; border-radius:4px;background-color: #ffffff; "> ';
echo "  <p> Please read Your orders here (Time : month/day/year):</p>" ; 
echo "</div>";
echo ' <div class="ck_inst" style="padding:20px;font-size:16px; background-color: transparent;border: 1px solid silver; border-radius:4px;"> ';

global $page,$addonPathCode, $addonDataFolder, $addonRelativeCode; 
require('Language.php');

$ofile = $addonDataFolder.'/orderentries.md';

if (!file_exists($ofile))  { 
echo '<button onclick="history.back()" style=" border: 2px solid gray; border-radius:5px; width:40px;" class="btn-outline-secondary"> &#8617;</button>';
echo "<br> No orderfile exists !";
exit; 
}    
 /* the file exists ! */
$f = fopen($ofile, "r") or exit("Unable to open file!");

echo " <em><center> Your orders (from orderentries.md) : <br></em></center>";
 
if (file_exists($ofile)) {readfile($ofile, "r"); } 
 
echo "<br> </div>";
?>