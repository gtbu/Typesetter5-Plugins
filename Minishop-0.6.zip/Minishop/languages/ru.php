 <?php
// This Program is released under GPL 2
// Copyright Bernd Dau
// see LICENSE.txt // to improve ! - gtranslate...
$Lang = 'ru';
$Mtxt['Welcome to Minishop Administration'] = 'Dobro pozhalovat v Administratsiyu Minishopa';
$Mtxt['Categories available']  = 'Dostupnyye kategorii';
$Mtxt['Category']              = 'Kategoriya';
$Mtxt['follow Link to Delete'] = 'pereyti po ssylke dlya udaleniya';
$Mtxt['Edit Description']      = 'Izmenit opisaniye';
$Mtxt['follow Link to Edit']   = 'pereyti po ssylke dlya redaktirovaniya';
$Mtxt['Items available']       = 'Dostupnyye tovary';
$Mtxt['Item']                  = 'Veshch ';
$Mtxt['Price']                 = 'Tsena';
$Mtxt['Your Choices:']         = 'Vash vybor:';
$Mtxt['Manage Categories']     = 'Upravleniye kategoriyami';
$Mtxt['Add Category']          = 'Dobavit kategoriyu';
$Mtxt['Manage Items']          = 'Upravleniye elementami'; 
$Mtxt['Add Item']              = 'Dobavit element';
$Mtxt['to the Minishop']       = 'v Minishop';
$Mtxt['Edit Item']             = 'Redaktirovat element';
$Mtxt['Change Item']           = 'Izmenit element';
$Mtxt['Description']           = 'Opisaniye';
$Mtxt['could not open File ']  = 'ne mogu otkryt fayl ';
$Mtxt['OOPS, could not save '] = 'OOPS, ne smog sokhranit ';
$Mtxt['Save was successfull']  = 'Sokhranit udalos! ';
$Mtxt['Save Category']         = 'Sokhranit kategoriyu';
$Mtxt['Edit Category']         = 'Izmenit kategoriyu';
$Mtxt['Verify delete Category']= 'Podtverdit udaleniye kategorii';
$Mtxt['Verify delete Item']    = 'Podtverdit udaleniye elementa';
$Mtxt['Delete Category']       = 'Udalit kategoriyu';
$Mtxt['Delete Item']           = 'Udalit punkt';
$Mtxt[' was deleted']          = ' byl udalen';

// Special_Minishop
$Mtxt['Minishop']              = 'Minishop';
$Mtxt['Your order']            = 'Tvoya ochered';
$Mtxt[' times ']               = ' x ';

// Salutation
$Mtxt['Please enter the delivery Address below:']  = 'Pozhaluysta, vvedite adres dostavki nizhe:';
$Mtxt['Salutation']            = 'Privetstviye';
$Mtxt['salut']   = '<select name="salutation">
					<option>G-n</option>
					<option>G-zha</option>
					<option>Miss</option>
					</select>';
$Mtxt['Name']                  = 'Familiya';
$Mtxt['Prename']               = 'Imya';
$Mtxt['Street']                = 'Ulitsa';
$Mtxt['City']                  = 'Gorod';
$Mtxt['Zip Code']              = 'Pochtovyy indeks';
$Mtxt['Country']               = 'Strana';
$Mtxt['email']                 = 'El. adres';
$Mtxt['Order']                 = 'Zakaz';
$Mtxt['orderinfo']             = 'Dal neyshaya informatsiya';
$Mtxt['Yes']                   = 'Da';

$Mtxt['Your Order is been processed']     = 'Vash zakaz obrabatyvayetsya';
$Mtxt['follow Link for more Information'] = 'Shchelknite ssylku dlya polucheniya dopolnitel noy informatsii';
$Mtxt['postorder']             = 'Spasibo za vash zakaz, kotoryy budet obrabotan kak mozhno skoreye.                                  Vy poluchite vtoroye elektronnoye pis mo s instruktsiyami po oplate.';

$Mtxt['No_Items']              = 'Vy ne vybrali ni odnogo elementa, poprobuyte yeshche raz';
$Mtxt['OOPS_REQUIRED']         = 'Nekotoraya neobkhodimaya informatsiya otsutstvuyet "<em>%s</em>" ';
$Mtxt['js-Back']               = '<a class="goback" href="javascript:history.back();">Vernis</a>';
$Mtxt['Your Bill:']            = 'Ves zakaz: ';
$Mtxt['Concurrency']           = ' RUB';