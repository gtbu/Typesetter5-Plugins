<?php
// This Program is released under GPL 2
// Copyright Bernd Dau
// see LICENSE.txt

$Lang = 'de';

$Mtxt['Welcome to Minishop Administration']= 'Willkommen bei der Minishop Administration';
$Mtxt['Categories available']  = 'verfügbare Kategorien';
$Mtxt['Category']              = 'Kategorie';
$Mtxt['follow Link to Delete'] = 'zum Löschen Link klicken'; 
$Mtxt['Edit Description']      = 'Beschreibung ändern';
$Mtxt['follow Link to Edit']   = 'zum Editieren Link klicken';
$Mtxt['Items available']       = 'verfügbare Artikel';
$Mtxt['Item']                  = 'Artikel';
$Mtxt['Price']                 = 'Preis';
$Mtxt['Your Choices:']         = 'Ihre Auswahl:';
$Mtxt['Manage Categories']     = 'Kategorien bearbeiten';
$Mtxt['Add Category']          = 'Kategorie hinzufügen';
$Mtxt['Manage Items']          = 'Artikel bearbeiten';
$Mtxt['Add Item']              = 'Artikel hinzufügen';
$Mtxt['to the Minishop']       = 'zum Minishop';
$Mtxt['Edit Item']             = 'Artikel editieren';
$Mtxt['Change Item']           = 'Artikel ändern';
$Mtxt['Description']           = 'Beschreibung';
$Mtxt['could not open File ']  = 'Konnte die Datei nicht öffnen: ';
$Mtxt['OOPS, could not save '] = 'Konnte die Datei nicht speichern: ';
$Mtxt['Save was successfull']  = 'Speichern war erfolgreich!';
$Mtxt['Save Category']         = 'Speichern Kategorie';
$Mtxt['Edit Category']         = 'Kategorie ändern';
$Mtxt['Verify delete Category']= 'zu löschende Kategorie bestätigen';
$Mtxt['Verify delete Item']    = 'zu löschenden Artikel bestätigen';
$Mtxt['Delete Category']       = 'Kategorie löschen';
$Mtxt['Delete Item']           = 'Artikel löschen';
$Mtxt[' was deleted']          = ' wurde gelöscht';


// Special_Minishop
$Mtxt['Minishop']              = 'Minishop';
$Mtxt['Your order']            = 'Ihre Bestellung';
// Wegen einer unsauberen Programmierung ist hier kein html erlaubt
$Mtxt[' times ']                = ' Anzahl ';

// Salutation
$Mtxt['Please enter the delivery Address below:']  = 'Bitte Ihre Anschrift angeben:';

$Mtxt['Salutation']            = 'Anrede';
$Mtxt['salut']   = '<select name="salutation">
					<option>Herr</option>
					<option>Frau</option>
					<option>Dr.</option>
					</select>';

$Mtxt['Name']                  = 'Name';
$Mtxt['Prename']               = 'Vorname';
$Mtxt['Street']                = 'Straße';
$Mtxt['City']                  = 'Stadt';
$Mtxt['Zip Code']              = 'Postleitzahl';
$Mtxt['Country']               = 'Land';
$Mtxt['email']                 = 'Ihre eMail';
$Mtxt['Order']                 = 'Bestellen';
$Mtxt['orderinfo']             = 'Anmerkungen';
$Mtxt['Yes']                   = 'Ja';

$Mtxt['Your Order is been processed']     = 'Ihr Auftrag wurde entgegen genommen.';
$Mtxt['follow Link for more Information'] = 'folgen Sie dem Link für nähere Informationen';
$Mtxt['postorder']             = 'Vielen Dank für Ihre Bestellung.
                    Wir werden uns schnellst möglich bei Ihnen per email melden und Ihnen 
unsere Kontoverbindung mitteilen';

$Mtxt['No_Items']              = 'Sie haben keinen Artikel ausgewählt, bitte noch mal probieren.';
$Mtxt['OOPS_REQUIRED']         = 'Sie haben das Feld "<em>%s</em>" nicht ausgefüllt';
$Mtxt['js-Back']                = '<a href="javascript:history.back();">Sie können es noch mal versuchen</a>';
$Mtxt['Your Bill:']            = 'Summe der Rechnung: ';
$Mtxt['Concurrency']           = ' €';




