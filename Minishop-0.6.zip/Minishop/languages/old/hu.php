 <?php
// This Program is released under GPL 2
// Copyright Bernd Dau
// see LICENSE.txt
 
$Lang = 'en';

$Mtxt['Welcome to Minishop Administration'] = 'Üdvözöljük a Minibolt adminisztrációs felületén';
$Mtxt['Categories available']  = 'Elérhető kategóriák';
$Mtxt['Category']              = 'Kategória';
$Mtxt['follow Link to Delete'] = 'kövesse a hivatkozást a törléshez';
$Mtxt['Edit Description']      = 'Megjegyzés szerkesztése';
$Mtxt['follow Link to Edit']   = 'kövesse a hivatkozást a szerkesztéshez';
$Mtxt['Items available']       = 'Elérhető elemek';
$Mtxt['Item']                  = 'Elem';
$Mtxt['Price']                 = 'Ár';
$Mtxt['Your Choices:']         = 'Kiválasztottelemek';
$Mtxt['Manage Categories']     = 'Kategóriák kezelése';
$Mtxt['Add Category']          = 'Új kategória';
$Mtxt['Manage Items']          = 'Elemek kezelése'; 
$Mtxt['Add Item']              = 'Új elem';
$Mtxt['to the Minishop']       = 'a Minibolt-hoz';
$Mtxt['Edit Item']             = 'Elem szerkesztése';
$Mtxt['Change Item']           = 'Elem módosítása';
$Mtxt['Description']           = 'Leírás';
$Mtxt['could not open File ']  = 'nem nyitható meg az állomány ';
$Mtxt['OOPS, could not save '] = 'HOPPÁ, nem lehet menteni ';
$Mtxt['Save was successfull']  = 'A mentés sikeresen befejeződött';
$Mtxt['Save Category']         = 'Kategória mentése';
$Mtxt['Edit Category']         = 'Kategória szerkesztése';
$Mtxt['Verify delete Category']= 'Kategória törlésének megerősítése';
$Mtxt['Verify delete Item']    = 'Elem törlésének megerősítése';
$Mtxt['Delete Category']       = 'Kategória tőrlése';
$Mtxt['Delete Item']           = 'Elem törlése';
$Mtxt[' was deleted']          = ' törölve lett';

// Special_Minishop
$Mtxt['Minishop']              = 'Minibolt';
$Mtxt['Your order']            = 'Az Ön rendelése';
$Mtxt[' times ']               = ' X ';

// Salutation
$Mtxt['Please enter the delivery Address below:']  = 'Kérem adja meg a szállítási címet';
$Mtxt['Salutation']            = 'Megszólítás';
$Mtxt['salut']   = '<select name="salutation">
					<option>Mr.</option>
					<option>Mrs.</option>
					<option>Ms.</option>
					</select>';
$Mtxt['Name']                  = 'Surname';
$Mtxt['Prename']               = 'First Name';
$Mtxt['Street']                = 'Utca';
$Mtxt['City']                  = 'Település';
$Mtxt['Zip Code']              = 'Irányítószám';
$Mtxt['Country']               = 'Megye';
$Mtxt['email']                 = 'Your Email';
$Mtxt['Order']                 = 'Fizetés';
$Mtxt['orderinfo']             = 'Further Information';
$Mtxt['Yes']                   = 'Igen';

$Mtxt['Your Order is been processed']     = 'Your Order is being processed';
$Mtxt['follow Link for more Information'] = 'Click link for more Information';
$Mtxt['postorder']             = 'Thank You for Your Order which will be proccessed as soon as possible.
                   You will receive a second email with payment instructions.';

$Mtxt['No_Items']              = 'You did not choose any items, Please try again';
$Mtxt['OOPS_REQUIRED']         = 'Some required information is missing "<em>%s</em>"';
$Mtxt['js-Back']               = '<a href="javascript:history.back();">go back</a>';
$Mtxt['Your Bill:']            = 'Order Total: ';
$Mtxt['Concurrency']           = ' GBP';