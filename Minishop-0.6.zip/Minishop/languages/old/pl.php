 <?php
// This Program is released under GPL 2
// Copyright Bernd Dau
// see LICENSE.txt
 
$Lang = 'en';

$Mtxt['Welcome to Minishop Administration'] = 'Witamy w Panelu Administracyjnych MiniShop';
$Mtxt['Categories available']  = 'Dostępne kategorie';
$Mtxt['Category']              = 'Kategoria';
$Mtxt['follow Link to Delete'] = 'Usuń';
$Mtxt['Edit Description']      = 'Edytuj opis';
$Mtxt['follow Link to Edit']   = 'Edytuj';
$Mtxt['Items available']       = 'Dostępne elementy';
$Mtxt['Item']                  = 'Element';
$Mtxt['Price']                 = 'Cena';
$Mtxt['Your Choices:']         = 'Twój wybór:';
$Mtxt['Manage Categories']     = 'Zarządzanie kategoriami';
$Mtxt['Add Category']          = 'Dodaj kategorię';
$Mtxt['Manage Items']          = 'Zarządzanie elementami'; 
$Mtxt['Add Item']              = 'Dodaj element';
$Mtxt['to the Minishop']       = 'do Minishop';
$Mtxt['Edit Item']             = 'Edytuj element';
$Mtxt['Change Item']           = 'Zmień element';
$Mtxt['Description']           = 'Opis';
$Mtxt['could not open File ']  = 'nie można otworzyć pliku ';
$Mtxt['OOPS, could not save '] = 'Niestety, nie można zapisać ';
$Mtxt['Save was successfull']  = 'Zapis powiódł się!';
$Mtxt['Save Category']         = 'Zapisz kategorię';
$Mtxt['Edit Category']         = 'Edytuj kategorię';
$Mtxt['Verify delete Category']= 'Potwierdź usunięcie kategorii';
$Mtxt['Verify delete Item']    = 'Potwierdź usunięcie elementu';
$Mtxt['Delete Category']       = 'Usuń kategorię';
$Mtxt['Delete Item']           = 'Usuń element';
$Mtxt[' was deleted']          = ' został usunięty';

// Special_Minishop
$Mtxt['Minishop']              = 'Minishop';
$Mtxt['Your order']            = 'Twoje zamówienie';
$Mtxt[' times ']               = ' X ';

// Salutation
$Mtxt['Please enter the delivery Address below:']  = 'Podaj adres do wysyłki:';
$Mtxt['Salutation']            = 'Tytuł';
$Mtxt['salut']   = '<select name="salutation">
					<option>Mr.</option>
					<option>Mrs.</option>
					<option>Ms.</option>
					</select>';
$Mtxt['Name']                  = 'Surname';
$Mtxt['Prename']               = 'First Name';
$Mtxt['Street']                = 'Ulica';
$Mtxt['City']                  = 'Ulica';
$Mtxt['Zip Code']              = 'Kod pocztowy';
$Mtxt['Country']               = 'Kraj';
$Mtxt['email']                 = 'Your Email';
$Mtxt['Order']                 = 'Zamówienie';
$Mtxt['orderinfo']             = 'Further Information';
$Mtxt['Yes']                   = 'Tak';

$Mtxt['Your Order is been processed']     = 'Your Order is being processed';
$Mtxt['follow Link for more Information'] = 'Click link for more Information';
$Mtxt['postorder']             = 'Thank You for Your Order which will be proccessed as soon as possible.
                   You will receive a second email with payment instructions.';

$Mtxt['No_Items']              = 'You did not choose any items, Please try again';
$Mtxt['OOPS_REQUIRED']         = 'Some required information is missing "<em>%s</em>"';
$Mtxt['js-Back']               = '<a href="javascript:history.back();">go back</a>';
$Mtxt['Your Bill:']            = 'Order Total: ';
$Mtxt['Concurrency']           = ' GBP';