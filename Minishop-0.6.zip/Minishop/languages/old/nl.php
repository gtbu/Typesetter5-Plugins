 <?php
// This Program is released under GPL 2
// Copyright Bernd Dau
// see LICENSE.txt
 
$Lang = 'en';

$Mtxt['Welcome to Minishop Administration'] = 'Welkom bij de Minishop Administratie';
$Mtxt['Categories available']  = 'Beschikbare Categorieen';
$Mtxt['Category']              = 'Categorie';
$Mtxt['follow Link to Delete'] = 'volg link om te verwijderen';
$Mtxt['Edit Description']      = 'Wijzig omschrijving';
$Mtxt['follow Link to Edit']   = 'volg link om aan te passen';
$Mtxt['Items available']       = 'Objecten beschikbaar';
$Mtxt['Item']                  = 'Item';
$Mtxt['Price']                 = 'Prijs';
$Mtxt['Your Choices:']         = 'Uw keuzes:';
$Mtxt['Manage Categories']     = 'Beheer categorieen';
$Mtxt['Add Category']          = 'Voeg Categorie toe';
$Mtxt['Manage Items']          = 'Beheer objecten'; 
$Mtxt['Add Item']              = 'Object toevoegen';
$Mtxt['to the Minishop']       = 'naar de Minishop';
$Mtxt['Edit Item']             = 'Object aanpassen';
$Mtxt['Change Item']           = 'Object veranderen';
$Mtxt['Description']           = 'Omschrijving';
$Mtxt['could not open File ']  = 'kan bestand niet openen ';
$Mtxt['OOPS, could not save '] = 'Oeps, niet opgeslagen ';
$Mtxt['Save was successfull']  = 'Succesvol opgeslagen!';
$Mtxt['Save Category']         = 'Categorie opslaan';
$Mtxt['Edit Category']         = 'Categorie bewerken';
$Mtxt['Verify delete Category']= 'Bevestig categorie verwijderen';
$Mtxt['Verify delete Item']    = 'Bevestig object verwijderen';
$Mtxt['Delete Category']       = 'Verwijder Categorie';
$Mtxt['Delete Item']           = 'Object verwijderen';
$Mtxt[' was deleted']          = ' is verwijderd';

// Special_Minishop
$Mtxt['Minishop']              = 'Miniwinkel';
$Mtxt['Your order']            = 'Uw order';
$Mtxt[' times ']               = ' X ';

// Salutation
$Mtxt['Please enter the delivery Address below:']  = 'Vul bezorg adres hieronder in:';
$Mtxt['Salutation']            = 'Dankboodschap';
$Mtxt['salut']   = '<select name="salutation">
					<option>Mr.</option>
					<option>Mrs.</option>
					<option>Ms.</option>
					</select>';
$Mtxt['Name']                  = 'Surname';
$Mtxt['Prename']               = 'First Name';
$Mtxt['Street']                = 'Straat';
$Mtxt['City']                  = 'Plaats';
$Mtxt['Zip Code']              = 'Postcode';
$Mtxt['Country']               = 'Land';
$Mtxt['email']                 = 'Your Email';
$Mtxt['Order']                 = 'Order';
$Mtxt['orderinfo']             = 'Further Information';
$Mtxt['Yes']                   = 'Ja';

$Mtxt['Your Order is been processed']     = 'Your Order is being processed';
$Mtxt['follow Link for more Information'] = 'Click link for more Information';
$Mtxt['postorder']             = 'Thank You for Your Order which will be proccessed as soon as possible.
                   You will receive a second email with payment instructions.';

$Mtxt['No_Items']              = 'You did not choose any items, Please try again';
$Mtxt['OOPS_REQUIRED']         = 'Some required information is missing "<em>%s</em>"';
$Mtxt['js-Back']               = '<a href="javascript:history.back();">go back</a>';
$Mtxt['Your Bill:']            = 'Order Total: ';
$Mtxt['Concurrency']           = ' GBP';