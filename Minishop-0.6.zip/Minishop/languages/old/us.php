 <?php
// This Program is released under GPL 2
// Copyright Bernd Dau
// see LICENSE.txt
 
$Lang = 'us';

$Mtxt['Welcome to Minishop Administration'] = 'Welcome to Minishop Administration';
$Mtxt['Categories available']  = 'Categories available';
$Mtxt['Category']              = 'Category';
$Mtxt['follow Link to Delete'] = 'follow Link to Delete';
$Mtxt['Edit Description']      = 'Edit Description';
$Mtxt['follow Link to Edit']   = 'follow Link to Edit';
$Mtxt['Items available']       = 'Items available';
$Mtxt['Item']                  = 'Item';
$Mtxt['Price']                 = 'Price';
$Mtxt['Your Choices:']         = 'Your Choices:';
$Mtxt['Manage Categories']     = 'Manage Categories';
$Mtxt['Add Category']          = 'Add Category';
$Mtxt['Manage Items']          = 'Manage Items'; 
$Mtxt['Add Item']              = 'Add Item';
$Mtxt['to the Minishop']       = 'to the Minishop';
$Mtxt['Edit Item']             = 'Edit Item';
$Mtxt['Change Item']           = 'Change Item';
$Mtxt['Description']           = 'Description';
$Mtxt['could not open File ']  = 'could not open File ';
$Mtxt['OOPS, could not save '] = 'OOPS, could not save ';
$Mtxt['Save was successfull']  = 'Save was successfull!';
$Mtxt['Save Category']         = 'Save Category';
$Mtxt['Edit Category']         = 'Edit Category';
$Mtxt['Verify delete Category']= 'Verify delete Category';
$Mtxt['Verify delete Item']    = 'Verify delete Item';
$Mtxt['Delete Category']       = 'Delete Category';
$Mtxt['Delete Item']           = 'Delete Item';
$Mtxt[' was deleted']          = ' was deleted';

// Special_Minishop
$Mtxt['Minishop']              = 'Minishop';
$Mtxt['Your order']            = 'Your order';
$Mtxt[' times ']               = ' x ';

// Salutation
$Mtxt['Please enter the delivery Address below:']  = 'Please enter the delivery Address below:';
$Mtxt['Salutation']            = 'Salutation';
$Mtxt['salut']   = '<select name="salutation">
					<option>Mr.</option>
					<option>Mrs.</option>
					<option>Ms.</option>
					</select>';
$Mtxt['Name']                  = 'Surname';
$Mtxt['Prename']               = 'First Name';
$Mtxt['Street']                = 'Street';
$Mtxt['City']                  = 'City';
$Mtxt['Zip Code']              = 'Zip Code';
$Mtxt['Country']               = 'Country';
$Mtxt['email']                 = 'Your Email';
$Mtxt['Order']                 = 'Order';
$Mtxt['orderinfo']             = 'Further Information';
$Mtxt['Yes']                   = 'Yes';

$Mtxt['Your Order is been processed']     = 'Your Order is being processed';
$Mtxt['follow Link for more Information'] = 'Click link for more Information';
$Mtxt['postorder']             = 'Thank You for Your Order which will be proccessed as soon as possible.
                   You will receive a second email with payment instructions.';

$Mtxt['No_Items']              = 'You did not choose any items, Please try again';
$Mtxt['OOPS_REQUIRED']         = 'Some required information is missing "<em>%s</em>"';
$Mtxt['js-Back']               = '<a class="goback" href="javascript:history.back();">go back</a>';
$Mtxt['Your Bill:']            = 'Order Total: ';
$Mtxt['Concurrency']           = ' $';