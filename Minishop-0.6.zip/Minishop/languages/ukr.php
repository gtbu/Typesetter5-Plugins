 <?php
// This Program is released under GPL 2
// Copyright Bernd Dau
// see LICENSE.txt // Ukraine , Griwna
$Lang = 'ukr';

$Mtxt['Welcome to Minishop Administration'] = 'Laskavo prosymo do administratsiyi mini-mahazynu';
$Mtxt['Categories available']  = 'Dostupni katehoriyi';
$Mtxt['Category']              = 'Katehoriyi';
$Mtxt['follow Link to Delete'] = 'pereyditʹ za posylannyam, shchob vydalyty';
$Mtxt['Edit Description']      = 'Redahuvaty opys';
$Mtxt['follow Link to Edit']   = 'pereyditʹ za posylannyam, shchob redahuvaty';
$Mtxt['Items available']       = 'Punkt dostupnyy';
$Mtxt['Item']                  = 'Item';
$Mtxt['Price']                 = 'Price';
$Mtxt['Your Choices:']         = 'Your Choices:';
$Mtxt['Manage Categories']     = 'Manage Categories';
$Mtxt['Add Category']          = 'Add Category';
$Mtxt['Manage Items']          = 'Manage Items'; 
$Mtxt['Add Item']              = 'Add Item';
$Mtxt['to the Minishop']       = 'to the Minishop';
$Mtxt['Edit Item']             = 'Edit Item';
$Mtxt['Change Item']           = 'Change Item';
$Mtxt['Description']           = 'Description';
$Mtxt['could not open File ']  = 'could not open File ';
$Mtxt['OOPS, could not save '] = 'OOPS, could not save ';
$Mtxt['Save was successfull']  = 'Save was successfull!';
$Mtxt['Save Category']         = 'Save Category';
$Mtxt['Edit Category']         = 'Edit Category';
$Mtxt['Verify delete Category']= 'Verify delete Category';
$Mtxt['Verify delete Item']    = 'Verify delete Item';
$Mtxt['Delete Category']       = 'Delete Category';
$Mtxt['Delete Item']           = 'Delete Item';
$Mtxt[' was deleted']          = ' was deleted';

// Special_Minishop
$Mtxt['Minishop']              = 'Minishop';
$Mtxt['Your order']            = 'Your order';
$Mtxt[' times ']               = ' x ';

// Salutation
$Mtxt['Please enter the delivery Address below:']  = 'Please enter the delivery Address below:';
$Mtxt['Salutation']            = 'Salutation';
$Mtxt['salut']   = '<select name="salutation">
					<option>Mr.</option>
					<option>Mrs.</option>
					<option>Ms.</option>
					</select>';
$Mtxt['Name']                  = 'Surname';
$Mtxt['Prename']               = 'First Name';
$Mtxt['Street']                = 'Street';
$Mtxt['City']                  = 'City';
$Mtxt['Zip Code']              = 'Zip Code';
$Mtxt['Country']               = 'Country';
$Mtxt['email']                 = 'Your Email';
$Mtxt['Order']                 = 'Order';
$Mtxt['orderinfo']             = 'Dodatkova informatsiya';
$Mtxt['Yes']                   = 'Tak';

$Mtxt['Your Order is been processed']     = 'Vashe zamovlennya obroblyayet sya';
$Mtxt['follow Link for more Information'] = 'Natysnit posylannya dlya otrymannya dodatkovoyi informatsiyi';
$Mtxt['postorder']             = 'Dyakuyemo za vashe zamovlennya, yake bude obrobleno yakomoha shvydshe.
                   Vy otrymayete druhyy elektronnyy lyst z instruktsiyamy shchodo oplaty.';

$Mtxt['No_Items']              = 'Vy ne vybraly zhodnoho elementa, sprobuyte shche raz';
$Mtxt['OOPS_REQUIRED']         = 'Vidsutnya deyaka neobkhidna informatsiya "<em>%s</em>"';
$Mtxt['js-Back']               = '<a class="goback" href="javascript:history.back();">Povertaysya</a>';
$Mtxt['Your Bill:']            = 'Us-oho zamovlennya: ';
$Mtxt['Concurrency']           = ' UAH';