<?php
// Ce programme est publié sous GPL 2
// Copyright Bernd Dau
// voir LICENCE.txt
 
$ Lang = 'fr';

$ Mtxt ['Welcome to Minishop Administration'] = 'Bienvenue dans l'administration Minishop';
$ Mtxt ['Categories available'] = 'Catégories disponibles';
$ Mtxt ['Category'] = 'Catégorie';
$ Mtxt ['follow Link to Delete'] = 'Suivre le lien pour supprimer';
$ Mtxt ['Edit Description'] = 'Modifier la description';
$ Mtxt ['follow Link to Edit'] = 'Suivre le lien pour éditer';
$ Mtxt ['Items available'] = 'Articles disponibles';
$ Mtxt ['Item'] = 'Item';
$ Mtxt ['Price'] = 'Prix';
$ Mtxt ['Your Choices:'] = 'Vos choix :';
$ Mtxt ['Manage Categories'] = 'Gérer les catégories';
$ Mtxt [''Add Category'] = 'Ajouter une catégorie';
$ Mtxt ['Manage Items'] = 'Gérer les éléments';
$ Mtxt ['Add Item'] = 'Ajouter un élément';
$ Mtxt ['to the Minishop'] = 'au Minishop';
$ Mtxt ['Edit Item'] = 'Modifier l'élément';
$ Mtxt ['Change Item'] = 'Modifier l'élément';
$ Mtxt ['Change Price'] = 'Modifier le prix';
$ Mtxt ['Description'] = 'Description';
$ Mtxt ['could not open File'] = 'impossible d'ouvrir le fichier';
$ Mtxt ['OOPS, could not save'] = 'Oups, n'a pas pu enregistrer';
$ Mtxt ['Save was successfull'] = 'L'enregistrement a réussi !';
$ Mtxt ['Save Category'] = 'Enregistrer la catégorie';
$ Mtxt ['Edit Category'] = 'Modifier la catégorie';
$ Mtxt ['Verify delete Category'] = 'Vérifier la suppression de la catégorie';
$ Mtxt ['Verify delete Item'] = 'Vérifier la suppression de l'élément';
$ Mtxt ['Delete Category'] = 'Supprimer la catégorie';
$ Mtxt ['Delete Item'] = 'Supprimer l'élément';
$ Mtxt ['was deleted'] = 'A été supprimé';

// Special_Minishop
$ Mtxt ['Minishop'] = 'Minishop';
$ Mtxt ['Your order'] = 'Votre commande';
$ Mtxt ['times'] = 'x';

// Salutation
$ Mtxt ['Please enter the delivery Address below:'] = 'Veuillez saisir l'adresse de livraison ci-dessous';
$ Mtxt ['Salutation'] = 'Salutation';
$ Mtxt ['salut'] = '<select name = "salutation">
                      <option> M. </option>
                      <option> Mme </option>
                      <option> Mme </option>
                    </select> ';
$ Mtxt ['Name'] = 'Nom';
$ Mtxt ['Prename'] = 'Prénom';
$ Mtxt ['Street'] = 'Rue';
$ Mtxt ['City'] = 'Ville';
$ Mtxt ['Zip Code'] = 'Code postal';
$ Mtxt ['Country] = 'Pays';
$ Mtxt ['email'] = 'Votre e-mail';
$ Mtxt ['Order'] = 'Commande';
$ Mtxt ['orderinfo'] = 'Informations complémentaires';
$ Mtxt ['Yes'] = 'Oui';

$ Mtxt ['Your Order is been processed'] = 'Votre commande est en cours de traitement';
$ Mtxt ['follow Link for more Information'] = 'Cliquez sur le lien pour plus d'informations';
$ Mtxt ['postorder'] = 'Merci pour votre commande qui sera traitée dans les plus brefs délais.
                   Vous recevrez un deuxième e-mail avec les instructions de paiement. ';

$ Mtxt ['No_Items'] = 'Vous n'avez choisi aucun élément, veuillez réessayer';
$ Mtxt ['OOPS_REQUIRED'] = 'Certaines informations obligatoires manquent "<em>% s </em>"';
$ Mtxt ['js-Back'] = '<a href="javascript:history.back();"> revenir en arrière </a>';
$ Mtxt ['Your Bill:'] = 'Total de la commande :';
$ Mtxt ['Concurrency'] = 'EU'; 