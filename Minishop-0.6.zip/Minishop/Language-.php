<?php
// Setting Language is easy, simply uncomment the desired Language
// or insert the desired countrycode


//USA
require ('languages/us.php');

//English
//require ('languages/en.php');

//France
//require ('languages/fr.php');

//German
// require ('languages/de.php');

//Magyarország 
//require ('languages/hu.php');

//Nederland 
//require ('languages/nl.php');

//Polska 
//require ('languages/pl.php');

//Slovensko  
//require ('languages/sk.php');
