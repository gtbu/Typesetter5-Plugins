<div>

<p>The Fontawsome 5 - Iconset is the follower of Fontawsome 4.x.&nbsp; It is very different from 4.x , because it</p>

<p>has several font-classes and - families and additional styling-options.</p>

<p>Therefore problems with parallel Font Awsome 4.x&nbsp; and 
<a href="https://fontawesome.com/how-to-use/on-the-web/setup/upgrading-from-version-4" target="_blank">upgrading to FA5</a> can arise.</p>

<hr />
<p><strong>Styling</strong></p>

<p>1. Many examples for the styling can be found at the&nbsp;<a href="https://fontawesome.com/how-to-use/on-the-web/styling/sizing-icons" target="_blank"> fontawsome- Website.</a></p>

<p>The styling can be simple&nbsp; as in this plugin (data-fa-transform and data-fa-mask are optional) :</p>

<p>&lt;span class=&quot;fab fa-accusoft fa-6x &quot; data-fa-transform=&quot;rotate-90&quot; style=&quot;color: #cc00cc;&quot;&gt;&amp;nbsp;&lt;/span&gt;</p>

<p>&nbsp;&nbsp; -- or</p>

<p><span class="fab fa-accessible-icon fa-border fas fa-comment" data-fa-mask="fas fa-comment" data-fa-transform="rotate-270" style="font-size: 20px;color: #3300ff;">&nbsp; </span>&lt;span class=&quot;fab fa-accessible-icon fa-border fas fa-comment&quot; data-fa-mask=&quot;fas fa-comment&quot;</p>

<p>data-fa-transform=&quot;rotate-270&quot; style=&quot;font-size: 20px;color: #3300ff;&quot;&gt;&amp;nbsp;&lt;/span&gt;</p>

<p>&nbsp;</p>

<p><strong>-<em>- but&nbsp; also more complicated like</em></strong></p>

<p><em>&lt;span class=&quot;fa-stack fa-2x&quot;&gt;</em></p>

<p><em>&lt;i class=&quot;fas fa-square fa-stack-2x&quot;&gt;&lt;/i&gt;</em></p>

<p><em>&lt;i class=&quot;fab fa-twitter fa-stack-1x fa-inverse&quot;&gt;&lt;/i&gt;</em></p>

<p><em>&lt;/span&gt;&nbsp;&nbsp;&nbsp;</em></p>

<p><strong><em>--&nbsp; and </em></strong></p>

<p><em>&lt;div class=&quot;fa-4x&quot;&gt; </em></p>

<p><em>&lt;i class=&quot;fas fa-magic&quot; data-fa-transform=&quot;shrink-8&quot; style=&quot;background:MistyRose&quot;&gt;&lt;/i&gt; </em></p>

<p><em>&lt;i class=&quot;fas fa-magic&quot; style=&quot;background:MistyRose&quot;&gt;&lt;/i&gt; </em></p>

<p><em>&lt;i class=&quot;fas fa-magic&quot; data-fa-transform=&quot;grow-6&quot; style=&quot;background:MistyRose&quot;&gt;&lt;/i&gt; </em></p>

<p><em>&lt;/div&gt;</em></p>

<p><strong><em>-- or </em></strong></p>

<p><em>&lt;div class=&quot;fa-4x&quot;&gt; </em></p>

<p><em>&lt;i class=&quot;fas fa-pencil-alt&quot; data-fa-transform=&quot;shrink-10 up-.5&quot; data-fa-mask=&quot;fas fa-comment&quot; style=&quot;background:MistyRose&quot;&gt;&lt;/i&gt; </em></p>

<p><em>&lt;i class=&quot;fab fa-facebook-f&quot; data-fa-transform=&quot;shrink-3.5 down-1.6 right-1.25&quot; data-fa-mask=&quot;fas fa-circle&quot; style=&quot;background:MistyRose&quot;&gt;&lt;/i&gt;</em></p>

<p><em>&lt;i class=&quot;fas fa-headphones&quot; data-fa-transform=&quot;shrink-6&quot; data-fa-mask=&quot;fas fa-square&quot; style=&quot;background:MistyRose&quot;&gt;&lt;/i&gt; </em></p>

<p><em>&lt;/div&gt;</em></p>

<hr />
<p><em>A momentary solution for complicated styling is to add two icons and after that to modify the code by hand :&nbsp; </em></p>

<p><em>1st icon :&nbsp; Modification of the &lt;span class=...&nbsp; and removal of the icon etc. , </em></p>

<p><em>2nd icon :&nbsp; Modification of the second &lt;span class=...&nbsp; to &lt;i class=... etc.</em></p>

<hr />
The momentary problem is ckeditor, who often simply removes <code> the < i </code>: <i class="fas fa-square"></i> (in the text)
<p>&nbsp;</p>
</div>
