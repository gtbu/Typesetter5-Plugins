<?php
defined('is_running') or die('Not an entry point...');

echo ' <hr size=1> ';

echo ' <div class="ck_inst" style="padding:20px;font-size:15px; background-color: transparent;border: 1px solid silver; border-radius:4px;background-color: #ffffff; "> ';
echo "  <p>  This Typesetter - addon installs the Font Awsome 5 icons (no svg-js).</p>
" ; echo "</div>";
echo ' <div class="ck_inst" style="padding:20px;font-size:15px; background-color: transparent;border: 1px solid silver; border-radius:4px;"> ';
 
$file = 'table.md';
global $addonPathCode; 
$plg = $addonPathCode;
$tab1 = '/table.md';
$file = $plg . $tab1 ;
#if (file_exists($file)) 
#{ echo "<br> The file $file exists"; }     /* the file exists ! */
$f = fopen($file, "r") or exit("Unable to open file!");
// read file line by line until the end of file (feof)
 echo " <em><center> </em></center>";
 
 if (file_exists($file)) {
 readfile( $file ); }
 #echo file_get_contents( $file );
 
  echo "</div>";
?>