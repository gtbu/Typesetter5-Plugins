<?php defined('is_running') or die('Not an entry point...');
// encoding UTF-8 ÄÖÜäöüß

class Cawsome5
{
static function caw5_getHead() {
  global $page, $addonRelativeCode;
  $page->css_user[] =  $addonRelativeCode . '/ckawsome5/resources/fontawesome-all.css';     
  $page->css_user[] =  $addonRelativeCode . '/ckawsome5/webfonts/fa-brands.css'; 
 $page->css_user[] =  $addonRelativeCode . '/ckawsome5/webfonts/fa-regular.css';  
 $page->css_user[] =  $addonRelativeCode . '/ckawsome5/webfonts/fa-solid.css';   
 $page->css_user[] =  $addonRelativeCode . '/ckawsome5/_webfontkit/all.css';
  $page->css_user[] = $addonRelativeCode . '/admin_cke_force_cawsome5.css';
     } 
/* $scripts['code'] = 'var fa5_base = "' . $addonRelativeCode . '";';  */

static function CKEditor_addcaw5Plugin($plugins) {
  global $addonRelativeCode;
   $plugins['ckawsome5'] = $addonRelativeCode . '/ckawsome5/';
  return $plugins;
}

static function CKEditor_addcaw5Config($options) { 
  global $addonRelativeCode;
  if ( version_compare(gpversion, '5.0') < 0 ){
    $options['contentsCss'] = $addonRelativeCode . '/ckawsome5/resources/v5.0.13-all-mod.css';
    $options['allowedContent'] = true;
  }
  return $options;
}
  /* filter hook - ala CKE_Glyhicons */
static function InlineEdit_Scripts7($scripts, $type){
    global $addonRelativeCode;
    if( $type !== 'text' ){
      return $scripts;
    }
	$scripts[] = array( 'object' => '$gp', 'code'   => '$gp.ck_base = "' . $addonRelativeCode . '";',);
    $scripts[]['code'] = 'CKEDITOR.dtd.$removeEmpty["span"] = false;'; /* as already in the js */
	$scripts[]['code'] = 'CKEDITOR.dtd.$removeEmpty.i = 0;';
	return gpAjax::InlineEdit_Text($scripts);
  }
  
  
}