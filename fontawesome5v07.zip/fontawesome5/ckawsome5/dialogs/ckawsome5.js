CKEDITOR.scriptLoader.load( $gp.ck_base + 'dialogs/fa5free-all-min2.js' );
// var ckpath = CKEDITOR.plugins.getPath('ckawsome5');
CKEDITOR.scriptLoader.load( CKEDITOR.plugins.getPath('ckawsome5')  + 'dialogs/fa5free-all-min2.js' );

var ck_base_is = typeof($gp.ck_base) == 'undefined' ? 'undefined' : $gp.ck_base;
console.log("$gp.ck_base = " + ck_base_is);

CKEDITOR.dialog.add('ckawsome5Dialog', function( editor ) {
	function getckawsome5icons(selectList ){
	     var result = [];
	     var scriptUrl = editor.awsome5Path;  
	    /* alert(scriptUrl) -> https://use.fontawesome.com/releases/v5.0.13/css/all.css; */
		 
	    $.ajax({
	        url: scriptUrl,
	        type: 'get',
	        dataType: 'html',
	        async: false,
	        success: function(response) {
	      var excludeStyles = [".fa.",".fa",".fa-lg",".fa-1x",".fa-2x",".fa-3x",".fa-4x",".fa-5x",".fa-6x",".fa-7x",".fa-8x",".fa-9x",".fa-10x",".fa-fw",".fa-ul",".fa-ul>",".fa-li",".fa-border",".fa-pull-left",".fa-pull-right",".fa-spin",".fa-pulse",".fa-rotate-90",".fa-rotate-180",".fa-rotate-270",".fa-flip-horizontal",".fa-flip-vertical",".fa-stack",".fa-stack-1x",".fa-stack-2x",".fa-inverse"];
	        				   
						 	        	
				var regxstyles = new RegExp(/\.[a-zA-Z_][\w-_]*[^\.\s\{#:\,;]/,"g" );   
	        	var styles = response.match(regxstyles);
				
				styles.sort();
				styles = jQuery.unique( styles );  	   				
			
	       $.each(styles, function( index, value ) {                    
	        var xstart=value.substring(0, 3).substring(1); 	
			if (xstart != 'fa' || excludeStyles.indexOf(value) > 0){ return; }  
										
	        	  value = value.substring(1);								
	        	  selectList.add(value, value);   
	       }) 

	        },   error: function (jqXHR, exception) { alert("Error loading Font Awsome 5 css: \n" + scriptUrl);},
	     }); 
}

/* -------------------------------------------------------------------------------------- */
	function getSelectionOptions(selectList, start, inc, many){    
	    var result = [];
	   	    var val = start; 
	    result.push(start); 
	    
	    many = many > 0 ? many : 5;
	    for(var i = 0; i < many; i++){
	    	val += inc;
	    	result.push(val);
	    }
	    
	    $.each(result, function( index, value ) {
	   		selectList.add(value, value);    
	   	})
	}  
/* --------------------------------------------------opt2 istyle------------------------------------------------------------ */	
		function getOptions2(selectList, start, inc, many){    
	    var result = istyle; 
		//var val = start; 	    
	    result.push(start); 
	    	   
	    $.each(result, function( index, value ) {
	   		selectList.add(value, value);    
	   	})
	}  

/* --------------------------------------------------opt3 trans------------------------------------------------------------ */	
		function getOptions3(selectList, start, inc, many){    //liefert die iconstyles	    var result = [];
	    var result = dtrans;
		//var val = start; 
	    
	    result.push(start); 
	    	   
	    $.each(result, function( index, value ) {
	   		selectList.add(value, value);    
	   	})
	}  
	
/* --------------------------------------------------opt4 mask------------------------------------------------------------ */	
		function getOptions4(selectList, start, inc, many){    
	    var result = dmask;
		// var val = start; 	    
	    result.push(start);  
	    	   
	    $.each(result, function( index, value ) {
	   		selectList.add(value, value);    
	   	})
	}  
/*---------------------------------------------------------------------------------------------------*/
  
	function formatckawsome5 (icon1) {  if (!icon1.id) { return icon1.text; } 
	     var text = icon1.text.replace(/fa-|\.|\-/gi, " ");   
	  
 var iconval = icon1.element.value;  
	  	  
 var cka_cla = "far ";   
 var nc1 = farfam.includes(iconval);   if(nc1 == true) { cka_cla = "far ";}  
 
 var nc2 = fabfam.includes(iconval);   if(nc2 == true) { cka_cla = "fab ";}  
 
 var nc3 = fasfam.includes(iconval);   if(nc3 == true) { cka_cla = "fas ";}  
  
    var icon1 = $('<span class="ckawsome5_options fab "><i class="'  + cka_cla   + iconval +   ' "></i> '  + text + "</span>"); 	

	  return icon1; 
	  }; 
	
/*---------------------------------------------------------------------------------------------*/
    return {
        title: 'Font Awsome 5',
        minWidth: 200,
        minHeight: 200,

        contents: [
            {
                id: 'options',
                label: 'Basic Settings',
                elements: [
                    {
					    type: 'select',   
					    id: 'ckawsome5box',    
					    label: 'Select Font Awsome 5',
					    validate: CKEDITOR.dialog.validate.notEmpty( "Font Awsome field cannot be empty." ),
					    items: [[ editor.lang.common.notSet, '' ]],
					    onLoad: function () {
						   	getckawsome5icons(this);
						   	var selectbx = $('#' + this.getInputElement().getAttribute('id'));  
						   	$(selectbx).select2({ width: "100%", templateResult: formatckawsome5, templateSelection: formatckawsome5});
					    },
					    onShow: function(){
					    	var selectbx = $('#' + this.getInputElement().getAttribute('id'));  
					    	$(selectbx).val('').trigger('change') ;
					    }
                    },
					
					{
                        type: 'select',   
                        id: 'iconstyle',   
                        label: 'Icon  options',
                        items: [[ editor.lang.common.notSet, '' ]],
                        onLoad: function (widget) {
                        	getOptions2(this, "", 1, 42);  
                        }
                    },
										
                    {
                        type: 'select',   
                        id: 'fatrans',    
						label: 'Data Transforms - see helpfile',   
						items: [[ editor.lang.common.notSet, '' ]],
                        onLoad: function (widget) {
                        	getOptions3(this, "", 1, 42);    
                        }
                    },
					
					{
                        type: 'select',   
                        id: 'famask',   
                        label: 'i Data Fa mask - see helpfile',
                        items: [[ editor.lang.common.notSet, '' ]],
                        onLoad: function (widget) {
                        	getOptions4(this, "", 1, 42);  
                        }
                    },
					
					{
                        type: 'select',   
                        id: 'textsize',   // Fontsize
                        label: 'Select  size',
                        items: [[ editor.lang.common.notSet, '' ]],
                        onLoad: function (widget) {
                        	getSelectionOptions(this, 8, 1, 42);
                        }
                    },
					
                    {   
                        type: "hbox",   
                        padding: 0,
                        widths: ["80%", "20%"],
                        children: [
                            {
                                id: 'fontcolor',
                                type: 'text',
                                label: 'Select color',
                                onChange: function( element ) {
                                	var idEl = $('#' +this.getInputElement().getAttribute('id'));
                                	idEl.css("background-color", idEl.val());
                                },
                                onKeyUp: function( element ) {
                                	var idEl = $('#' + this.getInputElement().getAttribute('id'));
                                	idEl.css("background-color", idEl.val());
                                },
        					    onShow: function(){
        					    	var idEl = $('#' + this.getInputElement().getAttribute('id'));  
                                	idEl.css("background-color", "");
        					    }
                            },
                            {
                                type: "button",
                                id: "fontcolorChooser",
                                "class": "colorChooser",
                                label: "Color",
                                style: "margin-left: 8px",
                                onLoad: function () {
                                    this.getElement().getParent().setStyle("vertical-align", "bottom")
                                },
                                onClick: function () {
                                    editor.getColorFromDialog(function (color) {
                                        color && this.getDialog().getContentElement("options", "fontcolor").setValue( color );
                                        this.focus()
                                    }, this)
                                }
                            }
                        ]
                    }
                ]
            },
        ],
        onOk: function() {
            var dialog = this;  

            var cka = editor.document.createElement( 'span' );
			
			var cka_size = dialog.getValueOf( 'options', 'textsize' );
			
            var cka_color = dialog.getValueOf( 'options', 'fontcolor' );

/*-----------------------------------------------------------------------------------------------------------*/
   var cka_fam = "fal ";   var  ckaic = dialog.getValueOf( 'options', 'ckawsome5box' ); /* icon - value */
	
	var nn1 = farfam.includes(ckaic);   if(nn1 == true) { cka_fam = "far ";}    
    var nn2 = fabfam.includes(ckaic);   if(nn2 == true) { cka_fam = "fab ";} 	 
	var nn3 = fasfam.includes(ckaic);  	if(nn3 == true) { cka_fam = "fas ";}
 
  var  ckaics = dialog.getValueOf( 'options', 'iconstyle' );  //  variable ckiconstyle
  var  ckaictra = dialog.getValueOf( 'options', 'fatrans' );
  var  ckaicmsk = dialog.getValueOf( 'options', 'famask' );
 /* -------------------------------------------------------------------*/
       var cka_class = cka_fam + ckaic + ' ' + ckaics ;      
	   
	   $( cka_class  ).append( "abc");
				
       var cka_style = ( cka_size != '' ? 'font-size: '+cka_size+'px;' : '' ) + ( cka_color != '' ? 'color: '+cka_color+';' : '' ) ;  //style=..
            
            cka.setAttribute( 'class', cka_class );
			
		if ( ckaictra )  cka.setAttribute( 'data-fa-transform',  ckaictra );   		
	    if ( ckaicmsk )  cka.setAttribute( 'data-fa-mask',  ckaicmsk );  
			
            if ( cka_style ) cka.setAttribute( 'style', cka_style );			
			
			cka.appendHtml("&nbsp;");  

            editor.insertElement( cka ); 
			
        }
    };
});

