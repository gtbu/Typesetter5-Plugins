/**
 *   ckawsome5 icons on the basis of  the free version 5 from
 *   https://github.com/FortAwesome/Font-Awesome 
 *
 *	awsome modified code of the ckawsome (4.7) plugin from 
 *   http://blackdevelop.com/io/ckawesome/ which is   
 *   Copyright (C) 2017 by Blackdevelop.com and under
 *   Licence  GNU GPL v3.
 */

CKEDITOR.on('instanceReady',function () { 
CKEDITOR.document.appendStyleSheet(CKEDITOR.plugins.getPath('ckawsome5') + 'resources/select2/select2.full.min.css');   }
    );
CKEDITOR.on('instanceReady',function () {
	CKEDITOR.document.appendStyleSheet(CKEDITOR.plugins.getPath('ckawsome5') + 'dialogs/ckawsome5.css');   }
	);
//  var ckpath = CKEDITOR.plugins.getPath('ckawsome5');

CKEDITOR.scriptLoader.load(CKEDITOR.plugins.getPath('ckawsome5') + 'resources/select2/select2.full.min.js');


CKEDITOR.dtd.$removeEmpty.span = false;
CKEDITOR.dtd.$removeEmpty['i'] = false;


CKEDITOR.plugins.add('ckawsome5', {
    requires: 'colordialog',
    icons: 'ckawsome5',    
   init: function(editor) {    
         
    	var config = editor.config;
    	editor.awsome5Path = config.awsome5Path ? config.awsome5Path : 'https://use.fontawesome.com/releases/v5.0.13/css/all.css'; 		
		
     CKEDITOR.document.appendStyleSheet(editor.awsome5Path); 
    	if( editor.addContentsCss ) { editor.addContentsCss(editor.awsome5Path); 	}
 
 
   CKEDITOR.dialog.add('ckawsome5Dialog', this.path + 'dialogs/ckawsome5.js');
		
	editor.addCommand( 'ckawsome5', new CKEDITOR.dialogCommand( 'ckawsome5Dialog', { allowedContent: 'span[class,style]{color,font-size}(*);' }));
        editor.ui.addButton( 'ckawsome5', {
              label: 'Insert ckawsome5',
              command: 'ckawsome5',
              toolbar: 'insert',
        });   
    }    
});
