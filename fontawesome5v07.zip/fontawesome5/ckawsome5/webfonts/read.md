Foints from  http://zavoloklom.github.io/material-design-iconic-font/

License: SIL OFL 1.1

The fonts are only added for completion.

The correct font-directory would be  ../fonts/m..  
