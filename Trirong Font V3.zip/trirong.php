<?php defined('is_running') or die('Not an entry point...');
// encoding UTF-8 ÄÖÜäöüß

function trirong_getHead() {
  global $page, $addonRelativeCode;
  $page->css_user[] =  $addonRelativeCode . '/css/trirong-fam.css';
  $page->css_user[] =  $addonRelativeCode . '/css/trirong-ck.css';
}

function trirong_FontList($options) { 
  if ( !isset($options['font_names']) || $options['font_names'] == "" ) {
    $defined_font_names =   "Arial/Arial,Helvetica,sans-serif;" .
                            "Comic Sans MS/Comic Sans MS,cursive;" .
                            "Courier New/Courier New,Courier,monospace;" .
                            "Georgia/Georgia,serif;" .
                            "Lucida Sans Unicode/Lucida Sans Unicode,Lucida Grande,sans-serif;" .
                            "Tahoma/Tahoma,Geneva,sans-serif;" .
                            "Times New Roman/Times New Roman,Times,serif;" .
                            "Trebuchet MS/Trebuchet MS,Helvetica,sans-serif;" .
                            "Verdana/Verdana,Geneva,sans-serif";
  } else {
    $defined_font_names = $options['font_names'];
  }
  $options['font_names'] =  "Trirong Thin/trirong-100,serif;" . 
                            "Trirong Thin Italic/trirong-100-italic,serif;" . 
							"Trirong ExtraLight/trirong-200,serif;" .
                            "Trirong ExtraLight Italic/trirong-200-italic,serif;" .  
                            "Trirong Light/trirong-300,serif;" .
                            "Trirong Light Italic/trirong-300-italic,serif;" .
                            "Trirong Regular/trirong-400,serif;" .
                            "Trirong Italic/trirong-400-italic,serif;" .
                            "Trirong Medium/trirong-500,serif;" .
							"Trirong Medium Italic/trirong-500-italic,serif;" .
							"Trirong SemiBold/trirong-600,serif;" .
							"Trirong SemiBold Italic/trirong-600-italic,serif;" .
							"Trirong Bold/trirong-700,serif;" .
							"Trirong Bold Italic/trirong-700-italic,serif;" .
							"Trirong ExtraBold/trirong-800,serif;" .
							"Trirong ExtraBold Italic/trirong-800-italic,serif;" .
							"Trirong Black/trirong-900,serif;" .
							"Trirong Black Italic/trirong-900-italic,serif;" .	
                            $defined_font_names; // appends standard/prevoiusly defined fonts to the list
  return $options;
}
