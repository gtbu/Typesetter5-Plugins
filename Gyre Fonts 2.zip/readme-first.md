The plugin installs a part of the latest fonts of the Polish TEX Gyre group under the GUST - Font - License.(without bold italic because of pluginsize)

The Gyre plugin is arranged hierarchically:
The upper level is only for the coordination of the individual font families for the Ckeditor.

In the subdirectories are ()also individually installable) plugins with the respective font-families, which can also be shifted (by sftp) directly under the directory 'Addons' to avoid a long dropdown in Ckeditor (then please uninstall the TexGyre fonts plugin and possibly delete the rest or move to a _temp-VZ). They can then be individually installed (activated) or uninstalled (deactivated).
Alternatively, the corresponding lines of unneeded fonts can be deleted in gyrefonts.php.

In the CSS subdirectories are some demo.html files with which the fonts can be viewed locally in the browser (possibly delete them on the web). Under Windows it is usually sufficient to double click on a * .ttf file with the left mouse button, which will result in a window with some demo - lines.

The fontname-fam.css files contain the TEX-Gyre font name, which is used by normal styling.
The ceditor requires its own distinguishable font family names for its dropdown, which can also be used for normal styling (i.e. both).

The fonts have a selfchosen fallback to serif.
For a quick check I recommend the Font Finder plugin for Firefox.
In the enclosed links.md you will find relevant links.
--------------------------------------------------------------------------------------------
Das Plugin installiert einen Teil der neusten Fonts der polnischen TEX Gyre Gruppe, die unter der GUST - Font - Lizenz stehen.

Das Gyre-Plugin ist hierachisch angeordnet : 
Die obere Ebene dient nur der Koordination der einzelnen Font-Familien f�r den Ckeditor. 

In den Unterverzeichnissen liegen die ()auch einzeln installierbaren) Plugins mit den jeweiligen Fontfamilien, die auch direkt unter das Verzeichnis 'Addons' hochverschoben werden k�nnen, um ein langes Dropdown im Ckeditor zu vermeiden(dann bitte das TexGyre-Fonts-Plugin deinstallieren und evtl. den Rest l�schen oder in ein _temp-VZ verschieben). Sie k�nnen dann einzeln installiert(aktiviert) oder deinstalliert(deaktiviert) werden. 
Alternativ k�nnen auch im gyrefonts.php die entsprechenden Zeilen nicht ben�tigter Fonts gel�scht werden.

In den CSS-Unterverzeichnissen liegen jeweils einige demo.html-Dateien, mit denen sich die Fonts lokal im Browser anschauen lassen(evtl. im Web l�schen). Unter Windows gen�gt es meistens sogar, eine *.ttf-Datei mit der linken Maustaste doppelt anzuklicken, wodurch sich ein Fenster mit einigen 
Demozeilen �ffnet.

Die fontname-fam.css - Dateien enthalten den TEX-Gyre-Fontnamen, der �ber normales Stylen verwendet wird. 
Der Ckeditor ben�tigt f�r sein Dropdown eigene unterscheidbare Fontfamilienamen, die aber auch f�r normales stylen verwendet werden k�nnen (d.h. beide).

Die Fonts haben ein selbstgew�hltes Fallback nach Serif.
Zur schnellen Untersuchung empfehle ich das Font Finder - Plugin f�r den Firefox.
In den beiliegenden links.md finden Sie ienige relevante Links.