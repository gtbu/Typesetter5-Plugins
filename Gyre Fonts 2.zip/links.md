https://www.fontsquirrel.com/tools/webfont-generator

ftp://ftp.gust.org.pl/pub/GUST/

http://www.gust.org.pl/projects/e-foundry/tex-gyre#Licensing

ftp://tug.org/historic/fonts/tex-gyre

ftp://ftp.icm.edu.pl/pub/CTAN/fonts/