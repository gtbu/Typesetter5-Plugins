<?php defined('is_running') or die('Not an entry point...');
// encoding UTF-8 ÄÖÜäöüß

function pagella2_getHead() {
  global $page, $addonRelativeCode;
  $page->css_user[] =  $addonRelativeCode . '/css/pagella2-fam.css';
  $page->css_user[] =  $addonRelativeCode . '/css/pagella2-ck.css';
}
function pagella2_FontList($options) { 
  if ( !isset($options['font_names']) || $options['font_names'] == "" ) {
    $defined_font_names =   "Arial/Arial,Helvetica,sans-serif;" .
                            "Comic Sans MS/Comic Sans MS,cursive;" .
                            "Courier New/Courier New,Courier,monospace;" .
                            "Georgia/Georgia,serif;" .
                            "Lucida Sans Unicode/Lucida Sans Unicode,Lucida Grande,sans-serif;" .
                            "Tahoma/Tahoma,Geneva,sans-serif;" .
                            "Times New Roman/Times New Roman,Times,serif;" .
                            "Trebuchet MS/Trebuchet MS,Helvetica,sans-serif;" .
                            "Verdana/Verdana,Geneva,sans-serif";
  } else {
    $defined_font_names = $options['font_names'];
  }
  $options['font_names'] =  "TEX pagella2 regular/tex-gyre-pagella-regular,serif;" .
                            "TEX pagella2 italic/tex-gyre-pagella-italic,serif;" .
							"TEX pagella2 bold/tex-gyre-pagella-700,serif;" .
	                       	$defined_font_names; // appends standard/prevoiusly defined fonts to the list
  return $options;
}
?>