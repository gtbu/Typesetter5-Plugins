<?php defined('is_running') or die('Not an entry point...');
// encoding UTF-8 ÄÖÜäöüß

function schola2_getHead() {
  global $page, $addonRelativeCode;
  $page->css_user[] =  $addonRelativeCode . '/css/schola2-fam.css';
  $page->css_user[] =  $addonRelativeCode . '/css/schola2-ck.css';
}
function schola2_FontList($options) { 
  if ( !isset($options['font_names']) || $options['font_names'] == "" ) {
    $defined_font_names =   "Arial/Arial,Helvetica,sans-serif;" .
                            "Comic Sans MS/Comic Sans MS,cursive;" .
                            "Courier New/Courier New,Courier,monospace;" .
                            "Georgia/Georgia,serif;" .
                            "Lucida Sans Unicode/Lucida Sans Unicode,Lucida Grande,sans-serif;" .
                            "Tahoma/Tahoma,Geneva,sans-serif;" .
                            "Times New Roman/Times New Roman,Times,serif;" .
                            "Trebuchet MS/Trebuchet MS,Helvetica,sans-serif;" .
                            "Verdana/Verdana,Geneva,sans-serif";
  } else {
    $defined_font_names = $options['font_names'];
  }
  $options['font_names'] =  "TEX schola2 regular/tex-gyre-schola-regular,serif;" .
                            "TEX schola2 italic/tex-gyre-schola-italic,serif;" .
							"TEX schola2 bold/tex-gyre-schola-700,serif;" .
	                        $defined_font_names; // appends standard/prevoiusly defined fonts to the list
  return $options;
}
?>