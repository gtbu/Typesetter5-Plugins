<?php
defined('is_running') or die('Not an entry point...');
echo ' <div style="padding:20px; max-width:600px;font-size:15px; border: 1px solid #0B3861; border-radius:4px;"> ';
echo "<br><b> Installation Protocol :</b><br><br>";

$dest = '/include/thirdparty/ckeditor46';

echo "<b>root dir is :</b>"; echo  $dataDir;
echo "<hr><b>addonpath :</b><br>";
global $addonPathCode; 
$src1 = $addonPathCode;
echo $addonPathCode;
if ( is_dir ( $addonPathCode ) )
{  echo "<hr>The addon directory for Ckeditor update 462  exists <br>"; }
#----------the unzip directory ------
$destz =  $dataDir . $dest;
mkdir( $destz , 0755, true); 
chmod( $destz , 0755 ); 
echo "<br><b>Destination dir is :</b>"; echo $destz;
#-------------------------------------------------#
echo "<hr>1. Write test -----<br>";
$newfile = $destz . "/" . "ck462.md"; echo "<br> $newfile ";

$fh = fopen($newfile, 'w') or die("Can't create file"); 
if (file_exists($newfile)) 
{ echo "<br> The file $newfile exists"; }
fclose($fh); 
chmod($newfile , 0755 );  unlink($newfile);	
#---------------------------------------------------
# http://www.php.net/manual/en/ziparchive.extractto.php
echo "<hr>2. unzip ckeditor 46 -----<hr>";
$zip = new ZipArchive;
$path  = getcwd() . $dest; 
if ($zip->open($addonPathCode . "/ckeditor46.zip") === TRUE) {
    $zip->extractTo($path);
    $zip->close(); 
	echo 'unzip of ckeditor46 ok';
} else {
    echo 'unzip failed';
}
#-----rename and backup-------------------------------
 echo "<hr>3. rename and backup -----<br>";
 
$dest3 =  $dataDir . "/" . "include/thirdparty/ckeditor_34/" ; echo $dest3; echo "<br>";

$dest4 =  $dataDir . "/" . "include/thirdparty/ckeditor_34b/" ;  echo $dest4; echo "<br>";

$dest5 =  $dataDir . "/" . "include/thirdparty/ckeditor46" ; echo $dest5; echo "<br>";

rename ($dest3 , $dest4 ); /*backup of previous version */
sleep(1); 

if ( is_dir ( $dest4 ) )
{ echo "<hr>directory ckeditor_34b created or exists with the previous version"; }
sleep(1); 
chmod( $dest5 , 0755 );

if ( is_dir ( $dest5 ) )
{  echo "<hr>directory ckeditor46 exists ready for renaming"; }
echo "<hr>"; echo "Directory ckeditor46 path is:"; echo $dest5 ;

if ( is_dir ( $dest5 ) )
{ rename( $dest5 , $dest3 ); } 

/* rename vz ckeditor46 in ckeditor_34 */
#rename( $dest5 , $dest3 );

if ( !is_dir ( $dest3 ) )
{ echo '<hr>renaming of ckeditor46 - directory failed' ; }
if ( is_dir ( $dest5 ) ) { rmdir($dest5); }

if ( is_dir ( $dest3 ) )
{  echo "<hr><b>Installation successful :</b> Please test under  Settings -> Ckeditor -> Example"; }

echo "<hr>You can delete the previous ckeditor-version completely unter 
Admin Links :  Remove old version";

echo "</div>";
?>