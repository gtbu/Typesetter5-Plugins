<?php
defined('is_running') or die('Not an entry point...');

echo ' <hr size=1> ';

echo ' <div class="ck_inst" style="padding:20px;max-width:600px;font-size:15px; background-color: transparent;border: 1px solid #0B3861; border-radius:4px;"> ';
echo "  <p><b> This addon updates ckeditor with version 4.62</b>. 
<hr>Please make a CMS-backup for safety before.</p>
<hr>
<p>1. The installation alone (without update under admin) already adds automatic further rights to install fonts (as necessary for bootstrap glyphicons 2 - plugin) and also adds <i>Checkbox, Radio, TextField, Textarea, Select, Button, ImageButton and  HiddenField</i> to the ckeditor toolbar.
<hr>
<p>
2. The update function is within the PLUGIN under : <em> Admin </em> Links : Update to ckeditor 4.62, where also a removal of the previous version (of the complete directory ckeditor_34b) after the update is offered. </p> <p>If You have problems with the installation then please use the point <i>support</i> in the repository of the plugin.  </p>
<br><p>3. The plugin contains a file ckeditor64.zip, which replaces the content of the includes/tirdparty/ckeditor_34 - directory.  </p>
<p> Therefore You can instead also make a directory __temp in the ckeditor_34-directory, shift its content into it and copy the content of the ckeditor64.zip into  the ckeditor_34 - directory with sftp.</p>
<p> <b>Attention</b> : <br></p>
<p> <b>Please do not press</b> the <i>'update to 4.62'</i> - button if the previous ckeditor 4.62 - update is already installed !!! At least delete the previous version before !</p>
 " ;
 echo "</div>";
?>