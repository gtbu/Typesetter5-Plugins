<?php 

defined('is_running') or die('Not an entry point...');

class AllowFontUploads46
{

  /* filter hook */
  static function AllowedTypes46($allowed_types){
    global $addonPathCode;
    // add common font file extensions to permit uploading them via finder or as part of CKEditor plugins' zip archives.
    $add_types = array('afm', 'eot', 'otf', 'pfa', 'pfb', 'pfm', 'ttc', 'ttf', 'ufo', 'woff', 'woff2' );
    $allowed_types = array_merge($allowed_types, $add_types);
    return $allowed_types;
  }

}
