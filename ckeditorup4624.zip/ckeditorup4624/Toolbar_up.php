<?php 

defined('is_running') or die('Not an entry point...');

class Toolbarext46 {

static public function CKEditorConfig46($options){
  $options['toolbar'][] = array('Checkbox', 'Radio', 'TextField', 'Textarea', 'Select', 'Button', 'ImageButton', 'HiddenField');
  return $options; }

}	

