<hr />
<div class="table-responsive">
<table class="table table-bordered" style="width: 100%;">
	<caption>&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; Font family<br />
	&nbsp;</caption>
	<thead>
		<tr>
			<td><span style="font-family:noto-serifthin-italic,serif;">1. Noto serif&nbsp; thin italic</span></td>
			<td>noto-serifthin-italic&nbsp; (always also :&nbsp; noto_serifthin_italic)</td>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td><span style="font-family:noto-serifthin,serif;">2. Noto serif&nbsp; thin</span></td>
			<td>noto-serifthin</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-serifextralight-italic,serif;">3. Noto serif&nbsp; extra light italic</span></td>
			<td>noto-serifextralight-italic</td>
		</tr>
		<tr>
			<td style="text-align: justify;"><span style="font-family:noto-serifextralight,serif;">4. Noto serif&nbsp; extra light</span></td>
			<td>noto-serifextralight</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-seriflight-italic,serif;">5. Noto serif light italic</span></td>
			<td>noto-seriflight-italic</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-seriflight,serif;">6. Noto serif light</span></td>
			<td>noto-seriflight</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-serifregular,serif;">7. Noto serif Regular</span></td>
			<td>noto-serifregular</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-serifitalic,serif;">8.</span><span style="font-family:noto-serifitalic,serif;"> Noto serif italic</span><span style="font-family:noto-serifitalic,serif;"></span></td>
			<td>noto-serifitalic</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-serifmedium-italic,serif;">9. Noto serif medium italic</span></td>
			<td>noto-serifmedium-italic</td>
		</tr>
		<tr>
			<td>10. Noto serif medium</td>
			<td>noto-serifmedium</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-serifsemibold-italic,serif;">11. Noto serif semibold italic</span></td>
			<td>noto-serifsemibold-italic</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-serifsemibold,serif;">12. Noto serif semibold</span></td>
			<td>noto-serifsemibold,</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-serifbold-italic,serif;">13. Noto serif bold italic</span></td>
			<td>noto-serifbold-italic</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-serifbold,serif;">14. Noto serif bold</span></td>
			<td>noto-serifbold</td>
		</tr>
		<tr>
			<td>-</td>
			<td>noto-serifextrabold</td>
		</tr>
		<tr>
			<td>-</td>
			<td>noto-serifextrabold-italic</td>
		</tr>
		<tr>
			<td>-</td>
			<td>noto-serifblack-italic</td>
		</tr>
		<tr>
			<td>-</td>
			<td>noto-serifblack</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-serifSCnThIt,serif;">1. Noto serif semi condensed thin it</span><span style="font-family:noto-serifSCnThIt,sans-serif;"></span></td>
			<td>noto-serifSCnThIt</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-serifsemicondensed-thin,sans-serif;">2.<span style="font-family:noto-serifsemicondensed_thin,serif;"> Noto serif semic ondensed thin&nbsp;</span></span></td>
			<td>noto-serifsemicondensed_thin</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-serifsemicondensed-thin,sans-serif;">3.</span><span style="font-family:noto-serifSCnXLtIt,sans-serif;">Noto serif semi condensed extra light italic</span><span style="font-family:noto-serifsemicondensed-thin,sans-serif;"></span></td>
			<td>noto-serifSCnXLtIt</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-serifSCnXLt,sans-serif;">4 </span><span style="font-family:noto-serifSCnXLt,sans-serif;">Noto serif semi condensed extra light</span><span style="font-family:noto-serifSCnXLt,sans-serif;"></span></td>
			<td>noto-serifSCnXLt</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-serifSCnLtIt,sans-serif;">5 Noto serif semi condensed light italic</span></td>
			<td>noto-serifSCnLtIt</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-serifsemicondensed-light,sans-serif;">6 </span>Noto serif semi condensed light<span style="font-family:noto-serifsemicondensed-light,sans-serif;"></span></td>
			<td>noto-serifsemicondensed-light</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-serifsemicondensed-light,sans-serif;"></span><span style="font-family:noto-serifsemicondensed-italic,sans-serif;"> </span><span style="font-family:noto-serifsemicondensed,sans-serif;">7 Noto serif semi condensed </span><span style="font-family:noto-serifsemicondensed-italic,sans-serif;"></span></td>
			<td>noto-serifsemicondensed</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-serifsemicondensed-italic,sans-serif;">8 Noto serif semi condensed italic</span></td>
			<td>noto-serifSCnIt</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-serifsemicondensed-medium,sans-serif;">9 Noto serif semi condensed medium</span></td>
			<td>noto-serifSCnMd</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-serifSCnMdIt,sans-serif;">10 Noto serif semi condensed medium italic</span></td>
			<td>noto-serifSCnMdIt</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-serifSCnSBd,sans-serif;">11 Noto serif semi condensed semi bold </span></td>
			<td>noto-serifSCnSBd</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-serifSCnSBd,sans-serif;">12</span><span style="font-family:noto-serifSCnBdIt,sans-serif;">Noto serif sem condensed semi bold italic</span><span style="font-family:noto-serifSCnSBd,sans-serif;"></span></td>
			<td>noto-serifSCnSBdIt</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-serifSCnBdIt,sans-serif;">13</span><span style="font-family:noto-serifsemicondensed-bold,sans-serif;"> Noto serif semi condensed bold </span><span style="font-family:noto-serifSCnBdIt,sans-serif;"></span></td>
			<td>noto-serifsemicondensed-bold</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-serifsemicondensed-bold,sans-serif;"></span>14 <span style="font-family:noto-serifSCnSBdIt,serif;">Noto serif semi condensed bold italic</span><span style="font-family:noto-serifsemicondensed-bold,sans-serif;"></span></td>
			<td>noto-serifSCnBdIt</td>
		</tr>
		<tr>
			<td>-</td>
			<td>noto-serifSCnXBd</td>
		</tr>
		<tr>
			<td>-</td>
			<td>noto-serifSCnXBdIt</td>
		</tr>
		<tr>
			<td>-</td>
			<td>noto_serifSCnBlkIt</td>
		</tr>
		<tr>
			<td>-</td>
			<td>noto-serifsemicondensed-black</td>
		</tr>
		<tr>
			<td>The extra-bold and black families are not contained because of
			the maximum upload size of the repository.</td><td></td>
		</tr>
	</tbody>
</table>
</div>
</div>