<?php
defined('is_running') or die('Not an entry point...');

echo ' <hr size=1> ';

echo ' <div class="ck_inst" style="padding:20px;font-size:15px; background-color: transparent;border: 1px solid silver; border-radius:4px;background-color: #ffffff; "> ';
echo "  <p> * This addon installs two google Noto Serif font - families  from https://www.google.com/get/noto/
(NotoSerif-hinted.zip) with OFL license.</p><p>
* The addon contains only the normal and the semi-condensed woff and woff2 fonts  because of the maximum upload-size of the Typesetter repository.
 </p><p> * After study of the long fontlist it is possible to remove unwanted fonts from the listing in the notosans.php.</p>
 <p>  * With the  fontsquirrel.com - generator it is possible to generate also eot- and svg - fonts.</p><p>
 * A description of the details of the font family is at https://de.wikipedia.org/wiki/Noto_Fonts
 .</p>


" ; echo "</div>";
echo ' <div class="ck_inst" style="padding:20px;font-size:15px; background-color: transparent;border: 1px solid silver; border-radius:4px;"> ';
 
$file = 'table.md';
global $addonPathCode; 
$plg = $addonPathCode;
$tab1 = '/table.md';
$file = $plg . $tab1 ;
#if (file_exists($file)) 
#{ echo "<br> The file $file exists"; }     /* the file exists ! */
$f = fopen($file, "r") or exit("Unable to open file!");
// read file line by line until the end of file (feof)
 echo " <em><center> Table of Noto Serif Fonts and  Font Families </em></center>";
 
 if (file_exists($file)) {
 readfile( $file ); }
 #echo file_get_contents( $file );
 
  echo "</div>";
?>