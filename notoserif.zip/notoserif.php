<?php defined('is_running') or die('Not an entry point...');
// encoding UTF-8 ÄÖÜäöüß

function notoserif_getHead() {
  global $page, $addonRelativeCode;
  $page->css_user[] =  $addonRelativeCode . '/fonts/notoserif-fam.css';
  $page->css_user[] =  $addonRelativeCode . '/fonts/notoserif-ck.css';
}
function notoserif_FontList($options) { 
  if ( !isset($options['font_names']) || $options['font_names'] == "" ) {
    $defined_font_names =   "Arial/Arial,Helvetica,sans-serif;" .
                            "Comic Sans MS/Comic Sans MS,cursive;" .
                            "Courier New/Courier New,Courier,monospace;" .
                            "Georgia/Georgia,serif;" .
                            "Lucida Sans Unicode/Lucida Sans Unicode,Lucida Grande,sans-serif;" .
                            "Tahoma/Tahoma,Geneva,sans-serif;" .
                            "Times New Roman/Times New Roman,Times,serif;" .
                            "Trebuchet MS/Trebuchet MS,Helvetica,sans-serif;" .
                            "Verdana/Verdana,Geneva,sans-serif";
  } else {
    $defined_font_names = $options['font_names'];
  }
  $options['font_names'] = "Nserif thin/noto-serifthin,serif;" .
                           "Nserif thin italic/noto-serifthin-italic,serif;" .
                           "Nserif ex lit ital/noto-serifextralight-italic,serif;" .
						   "Nserif extra lite/noto-serifextralight,serif;" .
						   "Nserif lit italic/noto-seriflight-italic,serif;" .
						   "Nserif light/noto-seriflight,serif;" .
						   "Nserif regular/noto-serifregular,serif;" .
						   "Nserif italic/noto-serifitalic,serif;" .
						   "Nserif med italic/noto-serifmedium-italic,serif;" .
						   "Nserif medium/noto-serifmedium,serif;" .
						   "Nserif semibold it/noto-serifsemibold-italic,serif;" .
						   "Nserif semibold/noto-serifsemibold,serif;" .
						   "Nserif bold ital/noto-serifbold-italic,serif;" .
						   "Nserif bold/noto-serifbold,serif;" .
						   "Nserif scond thin ital/noto-serifSCnThIt,serif;" .
						   "Nserif scond thin/noto-serifsemicondensed_thin,serif;" .
						   "Nserif scond ex lit ital/noto-serifSCnXLtIt,sans-serif;" .		
						   "Nserif scond ext light/noto-serifSCnXLt,serif;" .
						   "Nserif scond litw ital/noto-serifSCnLtIt,serif;" .
						   "Nserif scond lit/noto-serifsemicondensed-light,serif;" .
						   "Nserif scond reg/noto-serifsemicondensed,serif;" .																			
							   "Nserif scond it /noto-serifSCnIt,serif;" .	
						   "Nserif scond med it/noto-serifSCnMd,serif;" .	
						   "Nserif scond med it/noto-serifSCnMdIt,serif;" .
						   "Nserif scond sem bold/noto-serifSCnSBd,serif;" .
						   "Nserif scond sem bold it/noto-serifSCnSBdIt,serif;" .
						   "Nserif scond bold/noto-serifsemicondensed-bold,serif;" .
						   "Nserif scond bold it/noto-serifSCnBdIt,serif;" .
						   $defined_font_names; // appends standard/prevoiusly defined fonts to the list
						   return $options;
}?>