<div>
<h2>material-help</h2>

<p>Google material iconset <a href="http://zavoloklom.github.io/material-design-iconic-font/examples.html" target="_blank">examples </a></p>

<p>Formatations :</p>

<p>1.  <span class="zmdi zmdi-balance" style="font-size: 24px;color: #3300ff;">&nbsp;</span> &lt;span class=&quot;zmdi zmdi-balance&quot; style=&quot;font-size: 24px;color: #3300ff;&quot;&gt;&amp;nbsp;&lt;/span&gt;</p>

<p>like in this plugin</p>

<p>2.&nbsp;&nbsp;&nbsp; &lt;i class=&quot;zmdi zmdi-flower-alt&quot;&gt;&lt;/i&gt; and more can be found in the above examples.</p>

<p>Complex styling like</p>

<ul>
	<li>&lt;p&gt;&lt;i class=&quot;zmdi zmdi-pin animated infinite wobble zmdi-hc-fw&quot;&gt;&lt;/i&gt; wobble&lt;/p&gt;</li>
	<li class="even">&lt;p&gt;&lt;i class=&quot;zmdi zmdi-directions-bike animated infinite fadeInLeft zmdi-hc-fw&quot;&gt;&lt;/i&gt; fadeInLeft&lt;/p&gt;</li>
</ul>

<p>are not possible with the second dropdown and have to be added manually in the sourcecode.</p>

<hr />
<p>The file micstyle.js contains a list of the additional stylings which can be expanded (Editor : notepad++ portable etc.)</p>
</div>

<hr />