CKEDITOR.scriptLoader.load( $gp.ck_base + 'dialogs/micstyle.js' );
CKEDITOR.scriptLoader.load( CKEDITOR.plugins.getPath('ckmaterial')  + 'dialogs/micstyle.js' );

CKEDITOR.dialog.add('ckmaterialDialog', function( editor ) {
	function getCKMaterialIcons(selectList ){
	     var result = [];
	     var scriptUrl = editor.materialPath;
	     
	     $.ajax({
	        url: scriptUrl,
	        type: 'get',
	        dataType: 'html',
	        async: false,
	        success: function(response) {
	        	var excludeStyles = [".zmdi",".zmdi-hc-lg",".zmdi-hc-2x",".zmdi-hc-3x",".zmdi-hc-4x",".zmdi-hc-5x",".zmdi-hc-fw",".zmdi-hc-ul",".zmdi-hc-li",
				           ".zmdi-hc-li.zmdi-hc-lg",".zmdi-hc-border",".zmdi-hc-border-circle",".zmdi.pull-left",".zmdi.pull-right",".zmdi-hc-spin",
						   ".zmdi-hc-spin-reverse",".zmdi-hc-rotate-90",".zmdi-hc-rotate-180",".zmdi-hc-rotate-270",".zmdi-hc-flip-horizontal",
						   ".zmdi-hc-flip-vertical",".zmdi-hc-stack",".zmdi-hc-stack-1x",".zmdi-hc-stack-2x",".zmdi-hc-inverse"]; 
						   
						 	        	
				var regxstyles = new RegExp(/\.[a-zA-Z_][\w-_]*[^\.\s\{#:\,;]/,"g" );   
	        	var styles = response.match(regxstyles);
				
				styles.sort();
				styles = jQuery.unique( styles );
		      				
			
	        	$.each(styles, function( index, value ) {
	        		var xstart=value.substring(0, 5).substring(1); 			
	        		if (xstart != 'zmdi' || excludeStyles.indexOf(value) > 0){ return; }
					
	
					
	        		value = value.substring(1);									
	        		selectList.add(value, value);  
	        	})

	        },
	        error: function (jqXHR, exception) {
	            alert("Error loading Material css: \n" + scriptUrl);
	        },
	     });
	}
/*--------------------------------------------------------------------------------------------------------*/
	function getSelectionOptions(selectList, start, inc, many){
	    var result = [];
	    var val = start; 
	    
	    result.push(start);
	    
	    many = many > 0 ? many : 5;
	    for(var i = 0; i < many; i++){
	    	val += inc;
	    	result.push(val);
	    }
	    
	    $.each(result, function( index, value ) {
	   		selectList.add(value, value);
	   	})
	}
/*--------------------------------------------iconstyle--------------------------------------------------------------*/
function getOptions(selectList, start, inc, many){    
	    var result = micon1; 
		//var val = start; 	    
	    result.push(start); 
	    	   
	    $.each(result, function( index, value ) {
	   		selectList.add(value, value);    
	   	})
	}  
/* -----------------------------------------------------------------------------------------------------------*/
	function formatCKMaterial (icon) {    
	  if (!icon.id) { return icon.text; }
	  var text = icon.text.replace(/zmdi-|\.|\-/gi, " ");   /* remove  zmdi */	  
      var icon = $('<span class="ckmaterial_options"><i class="zmdi ' + icon.element.value + ' "></i> ' + text + "</span>");
	  
	  return icon;
	};
	
    return {
        title: 'Insert CKMaterial',
        minWidth: 200,
        minHeight: 200,

        contents: [
            {
                id: 'options',
                label: 'Basic Settings',
                elements: [
                    {
					    type: 'select',
					    id: 'ckmaterialbox',
					    label: 'Select Material',
					    validate: CKEDITOR.dialog.validate.notEmpty( "Material field cannot be empty." ),
					    items: [[ editor.lang.common.notSet, '' ]],
					    onLoad: function () {
						   	getCKMaterialIcons(this);
						   	var selectbx = $('#' + this.getInputElement().getAttribute('id'));  
						   	$(selectbx).select2({ width: "100%", templateResult: formatCKMaterial, templateSelection: formatCKMaterial});
					    },
					    onShow: function(){
					    	var selectbx = $('#' + this.getInputElement().getAttribute('id'));  
					    	$(selectbx).val('').trigger('change') ;
					    }
                    },
					
					{
                       type: 'select',
                       id: 'icstyle',
                       label: 'icon style',
                       items: [[ editor.lang.common.notSet, '' ]],
                       onLoad: function (widget) {
                       	getOptions(this, "", 1, 42);
                       }
                   },
					
                    {
                        type: 'select',
                        id: 'textsize',
                        label: 'Select  size',
                        items: [[ editor.lang.common.notSet, '' ]],
                        onLoad: function (widget) {
                        	getSelectionOptions(this, 8, 1, 42);
                        }
                    },
                    {   
                        type: "hbox",
                        padding: 0,
                        widths: ["80%", "20%"],
                        children: [
                            {
                                id: 'fontcolor',
                                type: 'text',
                                label: 'Select color',
                                onChange: function( element ) {
                                	var idEl = $('#' +this.getInputElement().getAttribute('id'));
                                	idEl.css("background-color", idEl.val());
                                },
                                onKeyUp: function( element ) {
                                	var idEl = $('#' + this.getInputElement().getAttribute('id'));
                                	idEl.css("background-color", idEl.val());
                                },
        					    onShow: function(){
        					    	var idEl = $('#' + this.getInputElement().getAttribute('id'));  
                                	idEl.css("background-color", "");
        					    }
                            },
                            {
                                type: "button",
                                id: "fontcolorChooser",
                                "class": "colorChooser",
                                label: "Color",
                                style: "margin-left: 8px",
                                onLoad: function () {
                                    this.getElement().getParent().setStyle("vertical-align", "bottom")
                                },
                                onClick: function () {
                                    editor.getColorFromDialog(function (color) {
                                        color && this.getDialog().getContentElement("options", "fontcolor").setValue( color );
                                        this.focus()
                                    }, this)
                                }
                            }
                        ]
                    }
                ]
            },
        ],
        onOk: function() {
            var dialog = this;

            var cka = editor.document.createElement( 'span' );
			
			var cka_size = dialog.getValueOf( 'options', 'textsize' );
            var cka_color = dialog.getValueOf( 'options', 'fontcolor' );
            var cka_class = " zmdi " + dialog.getValueOf( 'options', 'ckmaterialbox' );
            var cka_style = ( cka_size != '' ? 'font-size: '+cka_size+'px;' : '' ) + ( cka_color != '' ? 'color: '+cka_color+';' : '' ) ;
            
			var  matstyle = dialog.getValueOf( 'options', 'icstyle' ); var clstyle  = cka_class + ' ' + matstyle;
			  
            cka.setAttribute( 'class', clstyle);
		  			
            if ( cka_style ) cka.setAttribute( 'style', cka_style );

            cka.appendHtml("&nbsp;");

            editor.insertElement( cka );
        }
    };
});

