var micon1 = ["zmdi-hc-lg","zmdi-hc-2x","zmdi-hc-3x","zmdi-hc-4x","zmdi-hc-5x","zmdi-hc-fw","zmdi-hc-ul","zmdi-hc-li",
				           "zmdi-hc-li.zmdi-hc-lg","zmdi-hc-border","zmdi-hc-border-circle","zmdi.pull-left","zmdi.pull-right","zmdi-hc-spin",
						   "zmdi-hc-spin-reverse","zmdi-hc-rotate-90","zmdi-hc-rotate-180","zmdi-hc-rotate-270","zmdi-hc-flip-horizontal",
						   "zmdi-hc-flip-vertical","zmdi-hc-stack","zmdi-hc-stack-1x","zmdi-hc-stack-2x","zmdi-hc-inverse",
						   "animated infinite pulse zmdi-hc-fw mdc-text-blue",
						   "animated infinite fadeInLeft zmdi-hc-fw",]; 

console.log('micstyle.js was loaded');