/**
 *   CKMaterial icons on the basis of 
 * 
 *   http://blackdevelop.com/io/ckawesome/
 *   
 *   Copyright (C) 2017 by Blackdevelop.com
 *
 *   Licence under GNU GPL v3.
 */

CKEDITOR.on('instanceReady',function () { CKEDITOR.document.appendStyleSheet(CKEDITOR.plugins.getPath('ckmaterial') + 'resources/select2/select2.full.min.css');   });
CKEDITOR.on('instanceReady',function () { CKEDITOR.document.appendStyleSheet(CKEDITOR.plugins.getPath('ckmaterial') + 'dialogs/ckmaterial.css');   });
CKEDITOR.scriptLoader.load(CKEDITOR.plugins.getPath('ckmaterial') + 'resources/select2/select2.full.min.js');

CKEDITOR.dtd.$removeEmpty.span = false;
CKEDITOR.dtd.$removeEmpty['i'] = false;

CKEDITOR.plugins.add('ckmaterial', {
    requires: 'colordialog',
    icons: 'ckmaterial',
    
    init: function(editor) {
    	var config = editor.config;
    	editor.materialPath = config.materialPath ? config.materialPath : 'https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css';

    	CKEDITOR.document.appendStyleSheet(editor.materialPath);
    	if( editor.addContentsCss ) {
			editor.addContentsCss(editor.materialPath);
		}
    	
        CKEDITOR.dialog.add('ckmaterialDialog', this.path + 'dialogs/ckmaterial.js');
        editor.addCommand( 'ckmaterial', new CKEDITOR.dialogCommand( 'ckmaterialDialog', { allowedContent: 'span[class,style]{color,font-size}(*);' }));
        editor.ui.addButton( 'ckmaterial', {
              label: 'Insert CKMaterial',
              command: 'ckmaterial',
              toolbar: 'insert',
        });
    }
});
