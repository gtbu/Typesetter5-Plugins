<?php defined('is_running') or die('Not an entry point...');
// encoding UTF-8 ÄÖÜäöüß

class Material
{
static function Mat_getHead() {
  global $page, $addonRelativeCode;
  $page->css_user[] =  $addonRelativeCode . '/ckmaterial/resources/material-design-iconic-font.min.css';     
  $page->css_user[] = $addonRelativeCode . '/ckmaterial/admin_cke_force_materialicons.css';
     } 

static function CKEditor_addMaterialiconsPlugin($plugins) {
  global $addonRelativeCode;
   $plugins['ckmaterial'] = $addonRelativeCode . '/ckmaterial/';
  return $plugins;
}

static function CKEditor_addMaterialiconsConfig($options) { 
  global $addonRelativeCode;
  if ( version_compare(gpversion, '5.0') < 0 ){
    $options['contentsCss'] = $addonRelativeCode . '/ckmaterial/resources/material-design-iconic-font.min.css';
    $options['allowedContent'] = true;
  }
  return $options;
}
  /* filter hook - ala CKE_Glyhicons */
static function InlineEdit_Scripts1($scripts, $type){
    global $addonRelativeCode;
    if( $type !== 'text' ){
      return $scripts;
    }
    $scripts[]['code'] = 'CKEDITOR.dtd.$removeEmpty["span"] = false;'; /* as already in the js */
	$scripts[]['code'] = 'CKEDITOR.dtd.$removeEmpty.i = 0;';
	$scripts[] = array(   'object' => '$gp',   'code'   => '$gp.ck_base = "' . $addonRelativeCode . '";',);
    return gpAjax::InlineEdit_Text($scripts);
  }
  
}