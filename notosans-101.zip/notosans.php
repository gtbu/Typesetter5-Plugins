<?php defined('is_running') or die('Not an entry point...');
// encoding UTF-8 ÄÖÜäöüß

function notosans_getHead() {
  global $page, $addonRelativeCode;
  $page->css_user[] =  $addonRelativeCode . '/Fonts/notosans-fam.css';
  $page->css_user[] =  $addonRelativeCode . '/Fonts/notosans-ck.css';
}
function notosans_FontList($options) { 
  if ( !isset($options['font_names']) || $options['font_names'] == "" ) {
    $defined_font_names =   "Arial/Arial,Helvetica,sans-serif;" .
                            "Comic Sans MS/Comic Sans MS,cursive;" .
                            "Courier New/Courier New,Courier,monospace;" .
                            "Georgia/Georgia,serif;" .
                            "Lucida Sans Unicode/Lucida Sans Unicode,Lucida Grande,sans-serif;" .
                            "Tahoma/Tahoma,Geneva,sans-serif;" .
                            "Times New Roman/Times New Roman,Times,serif;" .
                            "Trebuchet MS/Trebuchet MS,Helvetica,sans-serif;" .
                            "Verdana/Verdana,Geneva,sans-serif";
  } else {
    $defined_font_names = $options['font_names'];
  }
  $options['font_names'] =  "Noto thin italic/noto-sansthin-italic,sans-serif;" .
                            "Noto thin/noto-sansthin,sans-serif;" .
                            "Noto ex lit ital/noto-sansextralight-italic,sans-serif;" .
                            "Noto extra lite/noto-sansextralight,sans-serif;" .
                            "5 Noto lit italic/noto-sanslight-italic,sans-serif;" .
                            "Noto light/noto-sanslight,sans-serif;" .
							"Noto regular/noto-sansregular,sans-serif;" .
                            "Noto italic/noto-sansitalic,sans-serif;" .
                            "Noto med italic/noto-sansmedium-italic,sans-serif;" .
                            "10 Noto medium/noto-sansmedium,sans-serif;" .
							"Noto semibold it/noto-sanssemibold-italic,sans-serif;" .
                            "Noto semibold/noto-sanssemibold,sans-serif;" .
							"Noto bold ital/noto-sansbold-italic,sans-serif;" .
                            "Noto bold/noto-sansbold,sans-serif;" .
                            "Noto black italic/noto-sansblack-italic,sans-serif;" .
							"Noto black/noto-sansblack,sans-serif;" .
							
							"Noto sem cond thin it/noto-sansSCnThIt,sans-serif;" .
                            "Noto sem cond thin/noto-sanssemicondensed-thin,sans-serif;" .
							"3 Noto cond ex lit it/noto-sansSCnXLtIt,sans-serif;" .
							"Noto sem cond ex light/noto-sansSCnXLt,sans-serif;" .
							"Noto sem cond lit it/noto-sansSCnLtIt,sans-serif;" .
                            "6 Noto sem cond lit/noto-sanssemicondensed-light,sans-serif;" .
							"Noto sem cond ital/noto-sanssemicondensed-italic,sans-serif;" .
                            "Noto sem cond reg/noto-sanssemicondensed,sans-serif;" .
							"Noto sem cond med it/noto-sansSCnMdIt,sans-serif;" .
                            "Noto sem cond medium/noto-sanssemicondensed-medium,sans-serif;" .
                            "Noto sem cond sem bold it/noto-sansSCnSBdIt,sans-serif;" .
                            "Noto sem cond sem bold/noto-sansSCnSBd,sans-serif;" .
							"Noto sem cond bold it/noto-sansSCnBdIt,sans-serif;" .
                            "13 Noto sem cond bold/noto-sanssemicondensed-bold,sans-serif;" .
							"Noto sem cond ex bold it/noto-sansSCnXBdIt,sans-serif;" .
                            "Noto sem cond ex bold/noto-sansSCnXBd,sans-serif;" .
							"Noto sem cond black it/noto-sansSCnBlkIt,sans-serif;" .
                            "Noto sem cond black/noto-sanssemicondensed-black,sans-serif;" .
                            
							$defined_font_names; // appends standard/prevoiusly defined fonts to the list
 return $options;
}
?>