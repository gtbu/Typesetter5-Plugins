<hr />
<div class="table-responsive">
<table class="table table-bordered" style="width: 100%;">
	<caption> &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Font family<br><br /></caption>
	<thead>
		<tr>
			<td><span style="font-family:noto-sansthin-italic,sans-serif;">Noto thin italic</span></td>
			<td>noto-sansthin-italic&nbsp; (always also :&nbsp; noto_sansthin_italic)</td>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td><span style="font-family:noto-sansthin,sans-serif;">Noto thin</span></td>
			<td>noto-sansthin</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-sansextralight-italic,sans-serif;">Noto extra light italic</span></td>
			<td>noto-sansextralight-italic</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-sansextralight,sans-serif;">Noto extra light</span></td>
			<td>noto-sansextralight</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-sanslight-italic,sans-serif;">Noto light italic</span></td>
			<td>noto-sanslight-italic</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-sanslight,sans-serif;">Noto light</span></td>
			<td>noto-sanslight</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-sansregular,sans-serif;">Noto Regular</span></td>
			<td>noto-sansregular</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-sansitalic,sans-serif;">Noto italic</span></td>
			<td>noto-sansitalic</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-sansmedium-italic,sans-serif;">Noto medium italic</span></td>
			<td>noto-sansmedium-italic</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-sansmedium,sans-serif;">10 Noto medium</span></td>
			<td>noto-sansmedium</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-sanssemibold-italic,sans-serif;">Noto semibold italic</span></td>
			<td>noto-sanssemibold-italic</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-sanssemibold,sans-serif;">Noto semibold</span></td>
			<td>noto-sanssemibold</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-sansbold-italic,sans-serif;">Noto bold italic</span></td>
			<td>noto-sansbold-italic</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-sansbold,sans-serif;">Noto bold</span></td>
			<td>noto-sansbold</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-sansblack-italic,sans-serif;">Noto black italic</span></td>
			<td>noto-sansblack-italic</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-sansblack,sans-serif;">Noto black</span></td>
			<td>noto-sansblack</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>1 Noto semi condensed extra lite italic</td>
			<td>noto-sansSCnXLtIt</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-sansSCnThIt,sans-serif;">2 Noto semi condensed thin italic</span></td>
			<td>noto-sansSCnThIt</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-sanssemicondensed-thin,sans-serif;">3 Noto semi condensed thin</span></td>
			<td>noto-sanssemicondensed-thin</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-sansSCnXLt,sans-serif;">4 Noto semi condensed extra light</span></td>
			<td>noto-sansSCnXLt</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-sansSCnLtIt,sans-serif;">5 Noto semi condensed light italic</span></td>
			<td>noto-sansSCnLtIt</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-sanssemicondensed-light,sans-serif;">6 Noto semi condensed light</span></td>
			<td>noto-sanssemicondensed-light</td>
		</tr>
		<tr>
			<td><span style="font-family:noto-sanssemicondensed-light,sans-serif;">7</span><span style="font-family:noto-sanssemicondensed-italic,sans-serif;"> Noto semi condensed italic </span></td>
			<td>noto-sanssemicondensed-italic</td>
		</tr>
		<tr>
			<td>8 <span style="font-family:noto-sanssemicondensed,sans-serif;">Noto semi condensed </span></td>
			<td>noto-sanssemicondensed</td>
		</tr>
		<tr>
			<td>9 <span style="font-family:noto-sansSCnMdIt,sans-serif;">Noto semi condensed medium italic</span></td>
			<td>noto-sansSCnMdIt</td>
		</tr>
		<tr>
			<td>10 <span style="font-family:noto-sanssemicondensed-medium,sans-serif;">Noto semi condensed medium</span></td>
			<td>noto-sanssemicondensed-medium</td>
		</tr>
		<tr>
			<td>11 <span style="font-family:noto-sansSCnSBdIt,sans-serif;">Noto semi condensed semi bold italic</span></td>
			<td>noto-sansSCnSBdIt</td>
		</tr>
		<tr>
			<td>12<span style="font-family:noto-sansSCnSBd,sans-serif;"> Noto sem condensed sem bold</span></td>
			<td>noto-sansSCnSBd</td>
		</tr>
		<tr>
			<td>13 <span style="font-family:noto-sansSCnBdIt,sans-serif;">Noto semi condensed bold italic</span></td>
			<td>noto-sansSCnBdIt</td>
		</tr>
		<tr>
			<td>14<span style="font-family:noto-sanssemicondensed-bold,sans-serif;"> Noto semi condensed bold&nbsp;</span></td>
			<td>noto-sanssemicondensed-bold</td>
		</tr>
		<tr>
			<td>&nbsp;(<span style="font-family:noto-sansSCnXBdIt,sans-serif;">Noto semi condensed extra bold italic)</span></td>
			<td>(noto-sansSCnXBdIt) - extra bold not contained !</td>
		</tr>
		<tr>
			<td>&nbsp;<span style="font-family:noto-sansXCnXBd,sans-serif;">(Noto semi condensed ex bold)</span></td>
			<td>(noto-sansSCnXBd) - extra bold not contained !</td>
		</tr>
		<tr>
			<td>15 <span style="font-family:noto-sansSCnBlkIt,sans-serif;">Noto semi condensed black italic</span></td>
			<td>noto-sansSCnBlkIt</td>
		</tr>
		<tr>
			<td>16 <span style="font-family:noto-sanssemicondensed-black,sans-serif;">Noto semi condensed black</span></td>
			<td>noto-sanssemicondensed-black</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
		
	</tbody>
</table>
</div>