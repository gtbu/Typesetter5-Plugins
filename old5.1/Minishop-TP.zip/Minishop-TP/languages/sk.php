 <?php
// This Program is released under GPL 2
// Copyright Bernd Dau
// see LICENSE.txt
 
$Lang = 'en';

$Mtxt['Welcome to Minishop Administration'] = 'Vitajte v administrácii minišopu';
$Mtxt['Categories available']  = 'Dostupné kategórie';
$Mtxt['Category']              = 'Kategória';
$Mtxt['follow Link to Delete'] = 'Nasleduj linku pre vymazanie';
$Mtxt['Edit Description']      = 'Editovať popis';
$Mtxt['follow Link to Edit']   = 'Nasleduj linku pre editovanie';
$Mtxt['Items available']       = 'Dostupné položky';
$Mtxt['Item']                  = 'Položka';
$Mtxt['Price']                 = 'Cena';
$Mtxt['Your Choices:']         = 'Tvoje voľby:';
$Mtxt['Manage Categories']     = 'Spravovať kategórie';
$Mtxt['Add Category']          = 'Pridať kategóriu';
$Mtxt['Manage Items']          = 'Spravovať položky'; 
$Mtxt['Add Item']              = 'Pridať položku';
$Mtxt['to the Minishop']       = 'do Minišopu';
$Mtxt['Edit Item']             = 'Editácia položky';
$Mtxt['Change Item']           = 'Zmeniť položku';
$Mtxt['Description']           = 'Popis';
$Mtxt['could not open File ']  = 'nepodarilo sa otvoriť súbor ';
$Mtxt['OOPS, could not save '] = 'Ooops, nepodarilo sa uložiť ';
$Mtxt['Save was successfull']  = 'Uloženie bolo úspešné!';
$Mtxt['Save Category']         = 'Uloženie kategórie';
$Mtxt['Edit Category']         = 'Editovať kategóriu';
$Mtxt['Verify delete Category']= 'Overenie vymazania kategórie';
$Mtxt['Verify delete Item']    = 'Overenie vymazania položky';
$Mtxt['Delete Category']       = 'Vymazať kategóriu';
$Mtxt['Delete Item']           = 'Vymazať položku';
$Mtxt[' was deleted']          = ' bola vymazaná';

// Special_Minishop
$Mtxt['Minishop']              = 'Minišop';
$Mtxt['Your order']            = 'Tvoja objednávka';
$Mtxt[' times ']               = ' X ';

// Salutation
$Mtxt['Please enter the delivery Address below:']  = 'Prosím zadaj nižšie adresu donášky';
$Mtxt['Salutation']            = 'Oslovenie';
$Mtxt['salut']   = '<select name="salutation">
					<option>Mr.</option>
					<option>Mrs.</option>
					<option>Ms.</option>
					</select>';
$Mtxt['Name']                  = 'Surname';
$Mtxt['Prename']               = 'First Name';
$Mtxt['Street']                = 'Ulica';
$Mtxt['City']                  = 'Mesto';
$Mtxt['Zip Code']              = 'PSČ';
$Mtxt['Country']               = 'Krajina';
$Mtxt['email']                 = 'Your Email';
$Mtxt['Order']                 = 'Objednávka';
$Mtxt['orderinfo']             = 'Further Information';
$Mtxt['Yes']                   = 'Áno';

$Mtxt['Your Order is been processed']     = 'Your Order is being processed';
$Mtxt['follow Link for more Information'] = 'Click link for more Information';
$Mtxt['postorder']             = 'Thank You for Your Order which will be proccessed as soon as possible.
                   You will receive a second email with payment instructions.';

$Mtxt['No_Items']              = 'You did not choose any items, Please try again';
$Mtxt['OOPS_REQUIRED']         = 'Some required information is missing "<em>%s</em>"';
$Mtxt['js-Back']               = '<a href="javascript:history.back();">go back</a>';
$Mtxt['Your Bill:']            = 'Order Total: ';
$Mtxt['Concurrency']           = ' GBP';