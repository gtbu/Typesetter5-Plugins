<?php
// This Program is released under GPL 2
// Copyright Bernd Dau
// see LICENSE.txt
defined('is_running') or die('Not an entry point...');

global $page, $addonRelativeCode, $addonPathData;	
	$page->head .= '<link rel="stylesheet" type="text/css" href="'.$addonRelativeCode.'/style.css'.'" />';
	
class Admin_Minishop
{
	var $categoryFile;
	var $itemFile;
	var $itemData = array();
	
	function GetCategories()
	{
		global $addonDataFolder;
		require('Language.php');
		$categoryFile = $addonDataFolder.'/categories.php';
		$Category = array();

		if( file_exists($categoryFile)){
			require($categoryFile);
		}

		return($Category);
	}

	function DisplayCategories()
	{
		global $description;
		$Category = $this->GetCategories();

		foreach ($Category as $key => $Category[$description])
		{
			echo '<tr><td>' . common::Link('Admin_Minishop', $key, 'cmd=delcat&id=' . $key). '</td><td>' . common::Link('Admin_Minishop', $Category[$description], 'cmd=editcat&id=' . $key) .'</td></tr>';
			echo "\r\n";
		}
	}

	function DeleteCategory()
	{
		require('Language.php');
		$CategoryData = array();
		global $description;
		$cmd = common::GetCommand();
		$Category = $this->GetCategories();
		$id = $_REQUEST['id'];

		switch ($cmd)
		{
		case 'delcat':
			echo '<b>' . $Mtxt['Verify delete Category'] .'</b><br>';
			echo '<form action="'.common::GetUrl('Admin_Minishop').'"><br>';
			echo '<input type="text" name="newdesc" size="30" value="' . $id . '" readonly><br>';
			echo '<input type="hidden" name="cmd" value="deletecat"><br>';
			echo '<input type="hidden" name="id" value="' . $id . '"><br>';
			echo '<input type="submit" value="' . $Mtxt['Delete Category'] . '"><br>';
			break;
		case 'deletecat':
			$i = 0;

			foreach ($Category as $key => $Category[$description])
			{
				if ($key != $id )
				{
					$CategoryData[$key] = $Category[$description];
				}
			}//	echo 'Debug :' . var_dump($CategoryData) . ':<br>';
			$this->SaveCategories($CategoryData);
			message($Mtxt['Category'] . ' ' . $id . $Mtxt[' was deleted']);
		}
	}

	function EditCategory()
	{
		global $description;
		require('Language.php');
		echo '<b>' . $Mtxt['Edit Category'] . '</b><br>';
		$id = $_REQUEST['id'];
		$Category = $this->GetCategories();
		echo '<form action="'.common::GetUrl('Admin_Minishop','cmd=edit').'"><br>';
		
		echo '<input type="text" name="newdesc" size="30" value="' . $Category[$id] . '">';
		echo '<input type="hidden" name="cmd" value="savecat">';
		echo '<input type="hidden" name="id" value="' . $id . '">';
		echo '<input type="submit" value="Change Description"><br>';
	}

	function AddCategory()
	{
		require('Language.php');
		echo '<b>' . $Mtxt['Add Category'] .'</b><br>';
		$ca = & $_REQUEST['cat'];
		$cat = $this->my_replace($ca, "no");
		$catdes = & $_REQUEST['catdesc'];
		$catdesc= $this->my_replace($catdes, "yes");
		$Category = $this->GetCategories();

		if (empty($cat) )
		{
			echo '<table class="bordered categ"><br>';
			echo '<th>Category</th><th>Description</th>';
			echo '<form action="'.common::GetUrl('Admin_Minishop','cmd=addcat').'"><br>';
			echo '<tr><td><input type="text" name="cat" size="10" value="' . $cat . '"></td>';
			echo '<td><input type="text" name="catdesc" size="30" value="' . $catdesc . '"></td></tr>';
			echo '<input type="hidden" name="cmd" value="addcat"><br>';
			echo '</table><br>';
			echo '<input type="submit" value="' . $Mtxt['Add Category'] . '">';

		}
		else
		{
			$Category[$cat] = $catdesc;//echo 'Debug:' . var_dump($Category) .':';
			$this->SaveCategories($Category);
		}
	}

	function SaveCategory()
	{
		global $description;
		require('Language.php');
		echo '<b>' . $Mtxt['Save Category'] . '</b><br>';
		$id = $_REQUEST['id'];
		$newdesc = $_REQUEST['newdesc'];
		$Category = $this->GetCategories();//	echo 'newdesc :' . $newdesc . '<br>';
		$Category[$id]= $newdesc;
		$this->SaveCategories($Category);
	}

	function SaveCategories($categoryData)
	{
		global $addonDataFolder;
		require('Language.php');
		$categoryFile = $addonDataFolder.'/categories.php';

		if (!gpFiles::SaveArray($categoryFile, 'Category', $categoryData) )
		{
			message($Mtxt['OOPS, could not save '] . $categoryFile);
			return false;
		}
		else
		{
			message($Mtxt['Save was successfull']);
		}
	}
	
 //  Item functions
	function GetItems()
	{
		global $addonDataFolder;
		require('Language.php');
		$itemFile = $addonDataFolder.'/items.php';
		$Item = array();

		if(file_exists($itemFile)){
			require($itemFile);
		}

		return($Item);
	}


 // $Item = array (   'Ford' => 'Mustang°Kategory1°6000', ....); aus items.php in _data/_addondata
 // function array_replace_keys : https://www.php.net/manual/de/function.array-replace.php
 
	function SaveItems($itemData)
	{
		global $addonDataFolder;
		require('Language.php');
		$itemFile = $addonDataFolder.'/items.php';

		if (!gpFiles::SaveArray($itemFile, 'Item', $itemData) )
		{
			message($Mtxt['OOPS, could not save '] . $itemFile );
			return false;
		}
		else
		{
			message($Mtxt['Save was successfull']);
		}
	}

	function DisplayCatkeys()
	{
		global $description;
		$Category = $this->GetCategories();// echo sizeof ( $Category );
		//echo var_dump($Category);
		$Item = $this->GetItems();//	echo 'debug myitem' . $myitem;
		$selected = false;
		if( isset($_REQUEST['id']) ){
			$myitem = & $_REQUEST['id'];
			$selected = strtok($Item[$myitem], '°');
			$selected = strtok('°');//	echo 'debug selected:' .  $selected ;
		}
		foreach ($Category as $key => $Category[$description])
		{
			if ($selected == $key)
			{
				echo '<option selected>' . $key . '</option>\n';
			}
			else
			{
				echo '<option>' . $key . '</option>\n';
			}
		}
	}

	function DeleteItem()
	{
		require('Language.php');
		$itemData= array();
		global $description;
		$cmd = common::GetCommand();
		$Item = $this->GetItems();
		$id = $_REQUEST['id'];

		switch ($cmd)
		{
		case 'delitem':
			echo '<b>' . $Mtxt['Verify delete Item'] .'</b><br>';
			echo '<form action="'.common::GetUrl('Admin_Minishop').'"><br>';
			echo '<input type="text" name="newdesc" size="30" value="' . $id . '" readonly><br>';
			echo '<input type="hidden" name="cmd" value="deleteitem"><br>';
			echo '<input type="hidden" name="id" value="' . $id . '"><br>';
			echo '<input type="submit" value="' . $Mtxt['Delete Item'] . '"><br>';
			break;
		case 'deleteitem':
			$i = 0;

			foreach ($Item as $key => $Item[$description])
			{
				if ($key != $id )
				{
					$ItemData[$key] = $Item[$description];
				}
			}//	echo 'Debug :' . var_dump($ItemData) . ':<br>';
			$this->SaveItems($ItemData);
			message($Mtxt['Item'] . ' ' . $id . $Mtxt[' was deleted']);
		}
	}

	function AddItem()
	{
		require('Language.php');
		echo '<b>' . $Mtxt['Add Item'] .'</b><br>'; // no strip_tags() : $Mtxt is an array !
		
		echo 'Prices xx.xx -- Weight per unit in the description !';
		
		$it = & $_REQUEST['item'];
		$item = $this->my_replace($it, "no");
		$itemdes = & $_REQUEST['itemdesc'];
		$itemdesc = $this->my_replace($itemdes, "yes");
		$itemprice = & $_REQUEST['itemprice'];
		$itemcat = & $_REQUEST['itemcat'];
		$Item = $this->GetItems();

		if (empty($item) )  // if empty : Add Item
		{
			echo '<table class="bordered categ"><br>';
			echo '<th>' . $Mtxt['Item'] . '</th><th>' . $Mtxt['Description'] . '</th><th>' . $Mtxt['Category'] . '</th><th>' . $Mtxt['Price'] . '</th>';
			echo '<form action="'.common::GetUrl('Admin_Minishop','cmd=additem').'"><br>';

			echo '<tr><td><input type="text" name="item" size="10" value=""></td>';  // Item - zB Gemüse
			
			echo '<td><input type="text" name="itemdesc" size="15" value=""></td>';
			
			echo '<td><select name="itemcat"><br>';  // Category of item
			$this->DisplayCatkeys();
			echo '<br></select></td>';
			
			echo '<td><input type="text" name="itemprice" size="5" value=""></td></tr>';
			echo '<input type="hidden" name="cmd" value="additem"><br>';
			echo '</table><br>';
			echo '<input type="submit" value="' . $Mtxt['Add Item'] .'">';

		}
		else
		{
			$Item[$item] = $itemdesc . '°' . $itemcat . '°' .$itemprice;//	echo 'Debug:' . var_dump($Item) .':';
			$this->SaveItems($Item);
		}
	}

	function DisplayItems()
	{
		global $description;
		$Item = $this->GetItems();// echo sizeof ( $Item );
		//echo var_dump($Item);
		foreach ($Item as $key => $Item[$description])
		{
			$desc = strtok($Item[$description], '°');
			$cat = strtok('°');
			$price= strtok('°');
			echo '<tr><td>' . common::Link('Admin_Minishop', $key, 'cmd=delitem&id=' . $key). '</td><td>' . common::Link('Admin_Minishop', $desc, 'cmd=edititem&id=' . $key) .'</td><td>' . $cat . '</td><td>' . $price . '</td></tr>';
		}
	}

	function EditItem()
	{
		global $description;
		require('Language.php');
		echo '<b>' . $Mtxt['Edit Item'] . '</b><br>';
		$id = & $_REQUEST['id'];
		
		$change = & $_REQUEST['change'];
		$price = & $_REQUEST['price'];
		$desc = & $_REQUEST['desc'];
		$itemcat = & $_REQUEST['itemcat'];
		$Item = $this->GetItems();    

		if ($change == '')
		{
			echo '<form action="'.common::GetUrl('Admin_Minishop','cmd=edititem').'"><br>';  // evtl cmd=edit
            $desc = strtok($Item[$id], '°');   // Item description
			$itemcat = strtok('°'); // Item category
			$price= strtok('°');
			
			echo '<table class="bordered"><tr>';
			echo '<th>'. $Mtxt['Item'] .'</th><th>' . $Mtxt['Edit Description'] . '</th><th>' . $Mtxt['Category'] . '</th><th>' . $Mtxt['Price'] . '</th><th>' . $Mtxt['Concurrency'] . '</th>';
						
			echo '</tr><tr>';
			echo '<td><input type="text" size="10" name="id" value="' . $id . '" readonly></td>';
			echo '<td><input type="text" size="15" name="desc" value="' . $desc . '"></td>';
			echo '<td><select name="itemcat"><br>';
			$this->DisplayCatkeys();
			echo '<br></select></td>';
			echo '<td><input type="text" size="5" name="price" value="' . $price . '"></td></tr><br>';
			echo '</table><br>';
			
			echo '<input type="hidden" name="cmd" value="edititem">';
			echo '<input type="hidden" name="change" value="' . $id . '"><br>';
			echo '<input type="submit" value="' . $Mtxt['Change Item'] . '"><br>';
			echo '</form>';
			// $id = zb Ford (Item)
		}
		else
		{//echo 'Save Item[$id]:' . $Item[$id];
			//echo '<br>desc:' . $desc ;
			//echo '<br>itemcat:' . $itemcat;
			//echo  '<br>price:' . $price;
			//echo '<br>';
			$Item[$id]= $desc . '°' . $itemcat . '°' . $price; 	
			echo $Item[$id];
			$this->SaveItems($Item);
		}
	}// The German umlauts are not illegal, but i didn't want them at anyway
	function my_replace($org, $relax)
	{
		if ($relax == "no" )
		{
			$unwanted = array('ä', 'ü', 'ß' , 'ö', ' ', '\\', '?', '!', '"', '{', '}', '€', '§', '$', '&', '%');
			$wanted = array('ae', 'ue', 'ss', 'oe', '_', '/', '');
		}
		else
		{// be more relaxed
			$unwanted = array('ä', 'ü', 'ß' , 'ö', '\\', '?', '!', '"', '{', '}', '&', '\%');
			$wanted = array('ae', 'ue', 'ss', 'oe', '/', '');
		}

		return str_replace($unwanted, $wanted, $org);
	}// Item
	function __construct()
	{
		global $addonDataFolder;
		require('Language.php');
		$categoryFile = $addonDataFolder.'/categories.php';
		echo '<div class="miniadmin"> <h3>' . $Mtxt['Welcome to Minishop Administration'] . '</h3>';		echo '<br>';
		$cmd = common::GetCommand();
		$show = true;//       echo '<h2>Debug:' .$cmd .'</h2><br>';
		if (common::LoggedIn() )
		{
			switch ($cmd)
			{
			case 'catlist':
				echo '<b>' . $Mtxt['Categories available'] . '</b><br>';
				echo '<table class="bordered catlist"><br>';
				echo '<th>' . $Mtxt['Category'] . '<br><sub>(' . $Mtxt['follow Link to Delete'] . ')</sub></th><th>' . $Mtxt['Edit Description'] . '<br><sub>(' . $Mtxt['follow Link to Edit'] . ')</sub></th>';
				$this->DisplayCategories();
				echo '</table><br>';
				break;
			case 'delcat':
				$this->DeleteCategory();
				break;
			case 'deletecat':
				$this->DeleteCategory();
				break;
			case 'editcat':
				$this->EditCategory();
				break;
			case 'addcat':
				$this->AddCategory();
				break;
			case 'savecat':
				$this->SaveCategory();
				break;
			case 'additem':
				$this->AddItem();
				break;
			case 'itemlist':
				echo '<br><b>' . $Mtxt['Items available'] .'</b><br>';
				echo '<table class="bordered"><br>';
				echo '<th>' . $Mtxt['Item'] .'<br><sub>(' . $Mtxt['follow Link to Delete'] .')</sub></th><th>' . $Mtxt['Edit Description'] .'<br><sub>(' . $Mtxt['follow Link to Edit'] . ')</th><th>'. $Mtxt['Category'] . '</th><th>'. $Mtxt['Price'] . '</th><th>'. $Mtxt['Concurrency'] . '</th>';  
				$this->DisplayItems();
				echo '</table><br>';
				break;
			case 'edititem':
				$this->EditItem();
				break;
			case 'delitem':
				$this->DeleteItem();
				break;
			case 'deleteitem':
				$this->DeleteItem();
				break;
			}
		}

		echo '<p>';
		echo '</p>';
		echo '<p>';
		echo '</p>';//		echo $addonDataFolder;
		echo '<br>';
		gpFiles::CheckDir($addonDataFolder);
		echo '<div class="choice">';
		echo '<h3>' . $Mtxt['Your Choices:'] . '</h3>';
		
		echo '<div style="padding:5px; text-align:center; font-size:16px; font-weight:bolder;">';
		echo common::Link('Admin_Minishop', $Mtxt['Manage Categories'],'cmd=catlist');
		echo '&nbsp;|&nbsp;';
		echo common::Link('Admin_Minishop', $Mtxt['Add Category'],'cmd=addcat');
		echo '</div>';
		
		echo '<div style="padding:5px; text-align:center; font-size:16px; font-weight:bolder;">';
		echo common::Link('Admin_Minishop', $Mtxt['Manage Items'],'cmd=itemlist');
		echo '&nbsp;|&nbsp;';
		echo common::Link('Admin_Minishop', $Mtxt['Add Item'],'cmd=additem');
		echo '</div>';
		
		echo '<p>';
		echo " </br> &#9664; &nbsp; ";  
		echo common::Link('Special_Minishop', $Mtxt['to the Minishop']);
		echo '</p>';
		echo '</div>';
		
		echo '</div>';
	}
}


