<?php
// This Program is released under GPL 2
// Copyright Bernd Dau
// see LICENSE.txt
defined('is_running') or die('Not an entry point...');
class Special_Minishop
{

	function Init()
	{
		global $page, $addonRelativeCode, $addonPathData;
		$page->head .= '<link rel="stylesheet" type="text/css" href="'.$addonRelativeCode.'/style.css'.'" />';
	}
//  Item functions
	function GetItems()
	{
		global $addonDataFolder, $config, $itemData, $description;
		require('Language.php');
		$itemFile = $addonDataFolder.'/items.php';

		if (!file_exists($itemFile))
		{
			message($Mtxt['could not open File '] . $itemFile);
			return false;
		}
		else
		{
			require($itemFile);
		}

		return($Item);
	}

	function DisplayItems()
	{
		global $description;
		$Item = $this->GetItems();
		$style='';
		$styleo= 'row_odd';
		$stylee= 'row_even';

		foreach ($Item as $key => $Item[$description])
		{
			$desc = strtok($Item[$description], '°');
			$cat = strtok('°');
			$price= strtok('°');
			$style = ($style == $styleo) ? $stylee : $styleo;
			#echo '<tr id="' . $style . '"><td>' , $key , '</td><td>' , common::Link('Minishop_', $desc, $key, 'cmd=showitem&id=' , $key) ,'</td>' , "\r\n" ;
			echo '<tr id="' . $style . '"><td>' . $key . '</td><td>'. common::Link('Minishop_'. $key  , $desc) ."</td>\r\n";
			echo '<td>' , $cat , '</td><td>' , $price , '</td><td><input type="text" size="3" name="', $key , '" value="0"></td></tr>' , "\r\n" ;
		}
	}

	function CheckOrderfields()
	{
		require('Language.php');
		$cnt=0;

		if (empty($_REQUEST['prename'] ) )
		{
			message($Mtxt['OOPS_REQUIRED'], $Mtxt['Prename']);
			$cnt++;
		}

		if (empty($_REQUEST['name'] ) )
		{
			message($Mtxt['OOPS_REQUIRED'], $Mtxt['Name']);
			$cnt++;
		}

		if (empty($_REQUEST['street'] ) )
		{
			message($Mtxt['OOPS_REQUIRED'], $Mtxt['Street']);
			$cnt++;
		}

		if (empty($_REQUEST['zipcode'] ) )
		{
			message($Mtxt['OOPS_REQUIRED'], $Mtxt['Zip Code']);
			$cnt++;
		}

		if (empty($_REQUEST['city'] ) )
		{
			message($Mtxt['OOPS_REQUIRED'], $Mtxt['City']);
			$cnt++;
		}

		if (empty($_REQUEST['email'] ) )
		{
			message($Mtxt['OOPS_REQUIRED'], $Mtxt['email']);
			$cnt++;
		}

		if ($cnt)
		{
			echo '<br>' . $Mtxt['js-Back'];
			return 1;
		}
	}

	function __construct()
	{
		global $description, $addonDataFolder,$orderd;
		global $langmessage, $config, $addonRelativeCode;
		$this->Init();
		require('Language.php');
		echo '<div class="avail"> <h2 id="shop_title">' , $Mtxt['Minishop'] , '</h2>';
		$cmd = common::GetCommand();

		switch ($cmd)
		{
		case 'buy':
			$style='';
			$styleo= 'row_odd';
			$stylee= 'row_even';
			$count=0;
			$summary=0;
			$orderd = '';
			$Item = $this->GetItems();
			echo '<div id="description">' , $Mtxt['Your order'] ,'</div>';
			echo '<div id="orderrealm">';

			foreach ($Item as $key => $Item[$description])
			{
				$desc = strtok($Item[$description], '°');
				$cat = strtok('°');
				$price= strtok('°');

				if ($_REQUEST["$key"] > 0 )
				{
					$count++;
					$style = ($style == $styleo) ? $stylee : $styleo;
					echo '<div id="' . $style .  '">';
					echo $_REQUEST[$key] , $Mtxt[' times '] , $key , ' ' , $Mtxt['Price'] ,' : ' , $price , '</div>', "\r\n" ;
									
					$summary = $summary + $_REQUEST[$key] * (float)($price) ;
					$orderd = $orderd . $_REQUEST[$key] . $Mtxt[' times '] . $key . ' ' . $Mtxt['Price'] .' : ' . $price .'<br>' . "\r\n" ;

				}
			}

			if ($count == 0)
			{
				message($Mtxt['No_Items']);
				echo '<div id="description">' . $Mtxt['No_Items'];
				echo '&nbsp;</div><br>' . $Mtxt['js-Back'] . '';
				#echo common::Link('Special_Minishop', $Mtxt['to the Minishop']);
				break;
			}
			$orderd	= $orderd . $Mtxt['Your Bill:'] . ' ' . $summary . $Mtxt['Concurrency'];
			echo '<div id="description">' . $Mtxt['Your Bill:'] . $summary . $Mtxt['Concurrency'];
			echo '</div>' ;
			// debug
			//echo '<pre>orderd';
			//echo $orderd;
			//echo '</pre>';
			echo '<b>' , $Mtxt['Please enter the delivery Address below:'] , '</b>';
			echo '<form method="post" action="'.common::GetUrl('Special_Minishop','cmd=order').'" id="orderform">';
			echo '<table><tr>';
			echo '<tr><td class="labels">';
			echo '<b>' , $Mtxt['Salutation'] , ' :</b></td><td>';
			echo $Mtxt['salut'] ;
			echo '</td>';
			echo '<tr><td class="labels"><b>' , $Mtxt['Name'] , ':</b></td><td><input type="text" size="30" name="name"></td>' , "\r\n" ;
			echo '<tr><td class="labels"><b>' , $Mtxt['Prename'] , ' :</b></td><td><input type="text" size="30" name="prename"></td>' , "\r\n" ;
			echo '<tr><td class="labels"><b>' , $Mtxt['Street'] , ' :</b></td><td><input type="text" size="30" name="street"></td>', "\r\n" ;
			echo '<tr><td class="labels"><b>' , $Mtxt['City'] , ' :</b></td><td><input type="text" size="30" name="city"></td>' , "\r\n" ;
			echo '<tr><td class="labels"><b>' , $Mtxt['Zip Code'] , ' :</b></td><td><input type="text" size="30" name="zipcode"></td>' , "\r\n" ;
			echo '<tr><td class="labels"><b>' , $Mtxt['Country'] , ' :</b></td><td><input type="text" size="30" name="country"></td>' , "\r\n" ;
			echo '<tr><td class="labels"><b>' , $Mtxt['email'] , ' :</b></td><td><input type="text" size="30" name="email"></td>' , "\r\n" ;
			echo '<tr><td class="labels"><b>' , $Mtxt['orderinfo'] , ' :</b></td><td><textarea cols="34" rows="4" name="orderinfo"></textarea></td>' , "\r\n" ;
			echo '<tr><td class="labels"><b>' , $Mtxt['Order'] , ':</b></td><td><input type="submit" name="order" Value="' , $Mtxt['Yes'] , '"></td>' , "\r\n" ;
			echo '</table>' , "\r\n" ;
			
			echo '<input type="hidden" name="cmd" value="order">';
			echo '<input type="hidden" name="orderd" value="' , $orderd , '">';
			//Baustelle
	//		echo '<input type="hidden" name="backlink" value="' , $orderd , '">';
			echo '</form></div>' , "\r\n" ;
			break;
					
			
		case '':
			echo '<div id="description">' , $Mtxt['Items available'] , '</div>';
			echo gpOutput::Area('tablerealm','<div class="tablerealm">%s</div>');
			echo '<div id="tablerealm" class="tablerealm">';
			echo '<form action="'.common::GetUrl('Special_Minishop','cmd=buy').'" id="form">';
			echo '<table id="table" class="table">';
			echo '<th>' , $Mtxt['Item'] , '</th><th>' , $Mtxt['Description'] , '<br><sub>(' , $Mtxt['follow Link for more Information'] , ')</th><th>' , $Mtxt['Category'] , '</th><th>' , $Mtxt['Price']  , '<br><sub>(' , $Mtxt['Concurrency'] , ')</sub></th><th>' , $Mtxt['Order'] , '</th>';
			$this->DisplayItems();
			echo '<tr><input type="hidden" name="cmd" value="buy">';
			echo '</table>';
			echo '<input type="submit" value="' , $Mtxt['Order'] , '"></tr>';
			echo '</form>';
			echo '</div>';
			
			break;
			
		case 'order':
			if ($this->CheckOrderfields())
			{
				break;
			}

			$message = $_REQUEST['salutation'] . '<br> ';
			$message = $message . $_REQUEST['prename'] . ' ';
			$message = $message . $_REQUEST['name'] . '<br>';
			$message = $message . $_REQUEST['street'] . '<br>';
			$message = $message . $_REQUEST['zipcode'] . ' ';
			$message = $message . $_REQUEST['city'] . '<br>';
			$message = $message . $_REQUEST['country'] . '<br>mailto:';
			$message = $message . $_REQUEST['email'] . '<br>';
			$message = $message . '---------------<br>';
			$message = $message . $_REQUEST['orderinfo'] . '<br>';
			$message = $message . '---------------<br>';
			$message = $message . $_REQUEST['orderd'] . '<br>';
			includeFile('tool/Emailer.php'); 
			echo '<div id="description"><br>';
			echo $Mtxt['Your Order is been processed'];
			echo '</div><div id="orderrealm">';
			$headers[] = 'MIME-Version: 1.0';
			$headers[] = 'Content-type: text/html; charset=UTF-8';
			$headers[] = 'Content-Transfer-Encoding: quoted-printable';
			echo $message;
			echo '</div><br>';//	echo 'toemail: ' . $config['toemail'];
			$orderentry = $addonDataFolder.'/orderentry.txt';
			gpFiles::Save($orderentry, $message);
			
			if( class_exists('\\gp\tool\\Emailer') ){
		        $shopmailer =new \gp\tool\Emailer();  // SendEmail($to,$subject,$message,$headers=array())...
				$shopmailer->SendEmail($config['toemail'], $Mtxt['Minishop'] . ': ' . $Mtxt['Your order'] , $message, $headers);
			    message($langmessage['message_sent']); }
				
			else { message($langmessage['OOPS']); }

			echo '<div id="postorder">';
			echo $Mtxt['postorder'];
			echo '</div></br>';
			break;
		}

		echo '<div id="back">';
		echo common::Link('Special_Minishop', $Mtxt['to the Minishop']);
		echo '</div>';
		echo '</br><hr size=1>';
		
		echo  '<div class="tablerealm  row">'; 
		echo  '<div class="notice col" style="max-width:95% !important;">';
        echo gpOutput::Get('Extra', 'Minishop_items');
		echo  '</div>';		
		echo '</br>';
				
		
		echo '</div>';
	}
}


