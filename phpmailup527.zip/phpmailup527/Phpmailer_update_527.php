<?php
defined('is_running') or die('Not an entry point...');
echo ' <div style="padding:20px; max-width:600px;font-size:15px; border: 1px solid #0B3861; border-radius:4px;"> ';
echo "<br><b> Installation Protocol :</b><br><br>";
#  root and addonpath
echo "<b>root dir is :</b>"; echo  $dataDir;
echo "<hr><b>addonpath :</b><br>";
global $addonPathCode; 
$src1 = $addonPathCode;
echo $addonPathCode;
if ( is_dir ( $addonPathCode ) )
{  echo "<hr>The addon directory for Phpmailer  public Version = '5.2.7' exists <br>"; }

$dest = '/include/thirdparty/PHPMailer';
$dest4 =  $dataDir . "/" . "include/thirdparty/PHPMailer_bk/" ;  
$dest5 =  $dataDir . "/" . "include/thirdparty/PHPMailer-tmp" ; echo $dest5; echo "<br>";

#----------the unzip directory ------
$destz =  $dest5;   echo "destz is : "; echo $destz; // include/thirdparty/PHPMailer_tmp
mkdir( $destz , 0755, true); 
chmod( $destz , 0755 ); 
if ( is_dir( $destz )) { 
echo "<hr><b>Tempdir is :</b>"; echo $destz;} 
#-------------------------------------------------#
echo "<hr>1. Tempdir write test -----<br>";
$newfile = $destz . "/php527.md"; echo "<br> $newfile ";

$fh = fopen($newfile, 'w') or die("Can't create file"); 
if (file_exists($newfile)) 
{ echo "<br> Success : The file $newfile exists in tempdir"; }
fclose($fh); 
chmod($newfile , 0755 );  unlink($newfile);	

#--------------unzip-------------------------------------
# http://www.php.net/manual/en/ziparchive.extractto.php
echo "<hr>2. unzip phpmailer 5.27 -----<hr>";

$zip = new ZipArchive;
$path  = $destz; 
echo "Path is :"; echo $path;  
echo "<br>addonPathCode is :"; echo $addonPathCode;
if ($zip->open($addonPathCode . "/PHPMailer.zip") === TRUE) {
    $zip->extractTo($path);
    $zip->close(); 
	echo '<br>unzip of phpmailer 5.2.7 ok';
} else {
    echo 'unzip failed';
}

#-----rename and backup--------------------------------------------------
echo "<hr>3. rename and backup -----<br>";
 
$dest3 =  $dataDir . "/" . "include/thirdparty/PHPMailer/" ; echo $dest3; echo "<br>";

$dest4 =  $dataDir . "/" . "include/thirdparty/PHPMailer_bk/" ;  echo $dest4; echo "<br>";


rename ($dest3 , $dest4 ); /* backup of previous version */
sleep(1); 

if ( is_dir ( $dest4 ) )
{ echo "<hr>directory PHPMailer_bk created or exists with the previous version"; }
sleep(1); 
# ---------------------tmp 

if ( is_dir ( $dest5 ) ) { chmod( $dest5 , 0755 ); 
echo "<hr>directory PHPMailer-tmp exists ready for renaming"; }

if ( is_dir ( $dest5 ) ) { rename( $dest5 , $dest3 ); } 

// rm 
if ( !is_dir ( $dest3 ) )
{ echo '<hr>renaming of PHPMailer-tmp - directory failed' ; }
if ( is_dir ( $dest5 ) ) { rmdir($dest5); }

if ( is_dir ( $dest3 ) )
{  echo "<hr><b>Installation successful ! "; }
# --version check
$destp = $dest3 . 'version.md'; 
$vdatei = fopen("$destp","rb"); $vcont = fgets($vdatei, 100); 
$vcont = preg_replace('/[^0-9]/','',$vcont); 
if($vcont != str_replace("527" , "" , $vcont)) echo " The new version is PHPMailer 5.2.7";
  
echo "<hr>You can delete the previous PHPMailer-version completely unter Admin Links :  Delete previous version";

echo "</div>";
?>