<?php
defined('is_running') or die('Not an entry point...');

echo ' <hr size=1> ';

echo ' <div class="ck_inst" style="padding:20px;max-width:600px;font-size:15px; background-color: transparent;border: 1px solid #0B3861; border-radius:4px;"> ';
echo "  <p><b> This addon updates Phpmailer to version 5.27</b>. 
<hr>Please make a CMS-backup for safety before.</p>
<hr>
<p> The update makes a backup of the old version. If You do not want to use the plugin, You can also replace the 
content of the phpmailer - directory manually with the content of  phpmailer.zip . </p>

<p> <b>Attention</b> : <br></p>
<p> <b>Please do not press</b> the <i>'update to 5.27'</i> - a second time ! At least delete the previous version before !</p>
 " ;
 echo "</div>";
?>