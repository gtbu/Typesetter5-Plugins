<?php
defined('is_running') or die('Not an entry point...');

echo ' <div class="ck_inst" style="padding:20px;max-width:600px;font-size:15px; border: 1px solid #0B3861; border-radius:4px;"> ';
echo "<b>Erase protocol : </b><br><br>"; 
$dest4 = $dataDir . "/include/thirdparty/PHPMailer_bk/" ;  echo "Backup path is :"; echo $dest4; 
echo "</div>";

if ( is_dir ( $dest4 ) )
{ echo ' <div class="ck_inst" style="padding:20px;max-width:600px;font-size:15px; border: 1px solid #0B3861; border-radius:4px;"> ';
echo ' Directory PHPMailer_bk exists !<br> ' ; echo "</div>";
chmod( $dest4 , 0755 ); 
}

# https://softontherocks.blogspot.de/2014/09/eliminar-un-directorio-completo-con-php.html MIT
  function delDir($dir){
     $result = false;
     if ($handle = opendir("$dir")){
         $result = true;
         while ((($file=readdir($handle))!==false) && ($result)){
             if ($file!='.' && $file!='..'){
                 if (is_dir("$dir/$file")){
                     $result = delDir("$dir/$file");
                 } else {
                     $result = unlink("$dir/$file");
                 }
             }
         }
         closedir($handle);
         if ($result){
             $result = rmdir($dir);
         }
     }
     return $result;
 }
 #---------------------------------------------------
 if ( is_dir ( $dest4 ) ) {delDir( $dest4 );}
 
 if ( is_dir ( $dest4 ) ) { rmdir( $dest4 ); }
 
if ( !is_dir ( $dest4 ) )
{ echo ' <div class="ck_inst" style="padding:20px;max-width:600px;font-size:15px; border: 1px solid #0B3861; border-radius:4px;"> ';
echo '<br> Removal of previous version successful ! ' ; 
echo "</div>";}
?> 
